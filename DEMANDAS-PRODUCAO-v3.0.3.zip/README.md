﻿# SISTEMA DE DEMANDAS - GOVERNANCA
## Versao 3.0.3 - Pacote de Producao

### COMO USAR:

1. Instalar Node.js (se nao tiver):
   - Baixe em: https://nodejs.org

2. Executar o sistema:
   - Clique duplo em: INICIAR-SISTEMA.bat
   - OU execute: node startup-with-updates.js

3. Acessar:
   - http://localhost:3000

### ESTRUTURA DOS ARQUIVOS:

- INICIAR-SISTEMA.bat       # Clique duplo para iniciar
- server.js                 # Backend principal  
- startup-with-updates.js   # Sistema de auto-update
- package.json              # Dependencias
- version.json              # Controle de versao
- web/                      # Interface do usuario
  - index.html             # Pagina principal
  - js/app.js              # Logica da aplicacao
  - css/style.css          # Estilos
- backend/                  # Backend alternativo
- config/                   # Configuracoes
- scripts/                  # Scripts auxiliares

### FUNCIONALIDADES:

- Auto-Update: Baixa atualizacoes do GitHub
- Anti-Cache: Headers para evitar cache
- SQL Server: Conexao com banco corporativo
- Timeline: Sistema de historico
- Responsivo: Desktop e mobile
- Multi-usuario: Diferentes perfis

### SOLUCAO DE PROBLEMAS:

- Node.js nao encontrado: Instale em https://nodejs.org
- Erro ao conectar banco: Verifique rede corporativa
- Porta 3000 em uso: Feche outras aplicacoes Node.js
- Cache do navegador: Pressione Ctrl+Shift+R

### SUPORTE:

- Contato: Equipe de Governanca
- Repositorio: kruetzmann2110/demandas
- Versao: 3.0.3