// Sistema de Gestão de Demandas - JavaScript Principal (Versão Híbrida)

// === VARIÁVEIS GLOBAIS ===
let currentUserRole = 'colaborador'; // Variável global para armazenar a role
let usersCache = []; // Cache de usuários
let usersCacheTime = 0; // Tempo do cache
const CACHE_DURATION = 30000; // 30 segundos

// === SISTEMA DE AUTO-REFRESH MELHORADO ===
let autoRefreshInterval = null;
let timelineModalOpen = false;
let currentTimelineViewDemandId = null;
let globalAutoRefreshInterval = null; // Nova variável para refresh geral

// Auto-refresh apenas da timeline (quando modal está aberto)
const startAutoRefresh = () => {
    if (autoRefreshInterval) clearInterval(autoRefreshInterval);
    
    autoRefreshInterval = setInterval(async () => {
        try {
            // Refresh apenas se a timeline estiver aberta
            if (timelineModalOpen && currentTimelineViewDemandId) {
                console.log('🔄 Auto-refresh da timeline em andamento...');
                await refreshTimelineView(currentTimelineViewDemandId);
            }
        } catch (error) {
            console.error('❌ Erro no auto-refresh da timeline:', error);
        }
    }, 5000); // Refresh a cada 5 segundos
    
    console.log('✅ Auto-refresh da timeline iniciado (5s)');
};

const stopAutoRefresh = () => {
    if (autoRefreshInterval) {
        clearInterval(autoRefreshInterval);
        autoRefreshInterval = null;
        console.log('⏹️ Auto-refresh da timeline parado');
    }
};

// Sistema de Auto-refresh SIMPLIFICADO (MELHOR PERFORMANCE)
let lastActivity = Date.now();
let isUserActive = true;
let isSystemPaused = false;
const INACTIVE_THRESHOLD = 5 * 60 * 1000; // 5 minutos de inatividade (aumentado)
const PAUSE_THRESHOLD = 20 * 60 * 1000; // 20 minutos para pausar (aumentado)
const ACTIVE_REFRESH_INTERVAL = 5 * 60 * 1000; // 5 minutos quando ativo (mais conservador)
const INACTIVE_REFRESH_INTERVAL = 15 * 60 * 1000; // 15 minutos quando inativo (reduzido)

const updateActivityTimestamp = () => {
    lastActivity = Date.now();
    
                    // ✅ SIMPLIFICADO: Apenas reativar se estava pausado
    if (isSystemPaused) {
        isSystemPaused = false;
        isUserActive = true;
        console.log('🔄 Sistema reativado - reiniciando auto-refresh');
        startGlobalAutoRefresh();
        return;
    }
    
    // Se usuário voltou a ser ativo
    if (!isUserActive) {
        isUserActive = true;
        console.log('👤 Usuário ativo - ajustando frequência');
        startGlobalAutoRefresh();
    }
};

// Monitorar atividade do usuário
['mousedown', 'mousemove', 'keypress', 'scroll', 'touchstart', 'click'].forEach(event => {
    document.addEventListener(event, updateActivityTimestamp, true);
});

// 🛡️ Detectar quando usuário fecha aba/aplicativo para limpar recursos
window.addEventListener('beforeunload', () => {
    console.log('💻 Aplicativo sendo fechado - limpando recursos...');
    stopGlobalAutoRefresh();
    stopAutoRefresh();
});

// Detectar quando aba perde foco (usuário mudou de aba)
document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
        console.log('🕰️ Aba perdeu foco - considerando como inatividade');
        // Não atualizar timestamp para que sistema detecte inatividade mais rápido
    } else {
        console.log('🔍 Aba voltou ao foco - registrando atividade');
        updateActivityTimestamp();
    }
});

const startGlobalAutoRefresh = () => {
    if (globalAutoRefreshInterval) clearInterval(globalAutoRefreshInterval);
    
    // ✅ SISTEMA SIMPLIFICADO - MELHOR PERFORMANCE
    globalAutoRefreshInterval = setInterval(async () => {
        try {
            const now = Date.now();
            const timeSinceActivity = now - lastActivity;
            
            // Pausar após 20 minutos de inatividade
            if (timeSinceActivity > PAUSE_THRESHOLD && !isSystemPaused) {
                isSystemPaused = true;
                isUserActive = false;
                console.log('⏸️ Sistema pausado após 20min de inatividade');
                stopGlobalAutoRefresh();
                return;
            }
            
            // Se pausado, não fazer nada
            if (isSystemPaused) return;
            
            // Detectar inatividade
            if (timeSinceActivity > INACTIVE_THRESHOLD && isUserActive) {
                isUserActive = false;
                console.log('😴 Usuário inativo - refresh mais lento');
                startGlobalAutoRefresh(); // Reiniciar com intervalo diferente
                return;
            }
            
            // ✅ REFRESH SIMPLIFICADO - Apenas se necessário
            const activeId = document.querySelector('.nav-link.active')?.id;
            if (activeId && activeId !== 'nav-home') {
                console.log(`🔄 Auto-refresh: ${activeId}`);
                
                // Recarregar apenas se necessário
                const lastCacheTime = demandsCache._lastUpdate || 0;
                const cacheAge = now - lastCacheTime;
                
                // Cache válido por 2 minutos
                if (cacheAge < 120000) {
                    console.log('⏭️ Cache válido, pulando refresh');
                    return;
                }
                
                // Atualizar dados
                await loadDemandsFromApi();
                demandsCache._lastUpdate = now;
                await refreshCurrentView();
                
                console.log('✅ Dados atualizados');
            }
        } catch (error) {
            console.error('❌ Erro no auto-refresh:', error);
        }
    }, isUserActive ? ACTIVE_REFRESH_INTERVAL : INACTIVE_REFRESH_INTERVAL);
    
    console.log('✅ Auto-refresh SIMPLIFICADO iniciado - melhor performance');
};

const stopGlobalAutoRefresh = () => {
    if (globalAutoRefreshInterval) {
        clearInterval(globalAutoRefreshInterval);
        globalAutoRefreshInterval = null;
        console.log('⏹️ Auto-refresh global das listas parado');
    }
};

// Indicador visual SIMPLIFICADO
const addRefreshIndicator = () => {
    const indicator = document.createElement('div');
    indicator.id = 'refresh-indicator';
    indicator.innerHTML = '🔄';
    indicator.title = 'Auto-refresh ativo';
    indicator.style.cssText = `
        position: fixed;
        top: 70px;
        right: 20px;
        z-index: 9999;
        background: rgba(111, 66, 193, 0.3);
        color: #6f42c1;
        padding: 6px 10px;
        border-radius: 15px;
        font-size: 11px;
        font-weight: bold;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        cursor: pointer;
        transition: all 0.3s ease;
        user-select: none;
        border: 1px solid rgba(111, 66, 193, 0.4);
    `;
    
    // Animação simples
    setInterval(() => {
        if (indicator.parentNode) {
            if (isSystemPaused) {
                indicator.textContent = '⏸️';
                indicator.style.background = 'rgba(220, 53, 69, 0.3)';
                indicator.style.color = '#dc3545';
            } else {
                indicator.textContent = '🔄';
                indicator.style.background = 'rgba(111, 66, 193, 0.3)';
                indicator.style.color = '#6f42c1';
            }
        }
    }, 5000);
    
    // Click para info
    indicator.addEventListener('click', () => {
        const minutes = Math.floor((Date.now() - lastActivity) / 60000);
        showToast(`Auto-refresh: ${isSystemPaused ? 'Pausado' : isUserActive ? 'Ativo (5min)' : 'Lento (15min)'}\nInativo há: ${minutes} minutos`, 'info');
    });
    
    document.body.appendChild(indicator);
};

// Função para atualizar apenas a view da timeline sem fechar o modal
const refreshTimelineView = async (demandId) => {
    try {
        console.log(`🔄 Atualizando timeline da demanda ${demandId}...`);
        
        // ✅ CORREÇÃO: Buscar timeline direto da API sem cache - compatível com backend atualizado
        const response = await fetch(`/api/demands/${demandId}/timeline`, {
            method: 'GET',
            headers: {
                'Accept': 'application/json'
            }
        });
        
        if (!response.ok) {
            const errorText = await response.text();
            console.error('❌ Erro na API timeline:', errorText);
            throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText}`);
        }
        
        const timelineResult = await response.json();
        console.log('📡 Resposta da API timeline:', timelineResult);
        
        if (timelineResult && timelineResult.success && timelineResult.data) {
            // ADAPTAÇÃO: Mapear colunas existentes para o formato esperado
            const timeline = timelineResult.data.map(event => ({
                id: event.id,
                demand_id: event.demand_id,
                usuario: event.user_name || 'Sistema', // Usar o nome real do usuário
                acao: event.event_text, // Usar event_text real da tabela
                descricao: event.event_text, // Usar event_text como descrição
                data_acao: event.event_date, // Usar event_date real da tabela
                created_at: event.created_at, // Usar created_at real da tabela
                user_id: event.user_id // Incluir user_id para referência
            }));
            
            console.log(`📅 Timeline processada: ${timeline.length} eventos`);
            
            // Atualizar apenas os eventos da timeline
            const timelineEvents = document.getElementById('timeline-events');
            if (timelineEvents) {
                timelineEvents.innerHTML = `
                    <div class="timeline">
                        ${timeline.map(event => `
                            <div class="timeline-item">
                                <div class="timeline-content">
                                    <div class="d-flex justify-content-between align-items-start">
                                        <div>
                                            <strong class="timeline-user">${getUserName(event.usuario || 'Sistema')}</strong>
                                            <p class="mb-1">${event.acao || 'Evento da timeline'}</p>
                                            ${event.descricao && event.descricao !== event.acao ? `<small class="text-muted">${event.descricao}</small>` : ''}
                                        </div>
                                        <small class="timeline-date">${formatDateTime(event.data_acao || event.created_at)}</small>
                                    </div>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                    ${timeline.length === 0 ? '<div class="text-center text-muted py-4">Nenhum evento na timeline ainda</div>' : ''}
                `;
                
                console.log('✅ Timeline atualizada no DOM com dados frescos');
            } else {
                console.error('❌ Elemento timeline-events não encontrado');
            }
            
        } else {
            console.error('❌ Resposta inválida da API timeline:', timelineResult);
        }
    } catch (error) {
        console.error('❌ Erro ao atualizar timeline em background:', error);
    }
};

// === FUNÇÕES AUXILIARES ===

// Mapear prioridade numérica do banco para string
const getPriorityString = (priority) => {
    // ✅ TRATAMENTO ROBUSTO: null, undefined, string vazia
    if (priority === null || priority === undefined || priority === '') {
        return 'Média'; // Default
    }
    
    // ✅ Se é número, converter para string
    if (typeof priority === 'number') {
        switch (priority) {
            case 3: return 'Alta';
            case 2: return 'Média';
            case 1: return 'Baixa';
            default: return 'Média';
        }
    }
    
    // ✅ Se é string, normalizar
    if (typeof priority === 'string') {
        const normalized = priority.toLowerCase().trim();
        switch (normalized) {
            case 'alta':
            case 'alto':
            case 'high':
                return 'Alta';
            case 'media':
            case 'média':
            case 'medio':
            case 'médio':
            case 'medium':
                return 'Média';
            case 'baixa':
            case 'baixo':
            case 'low':
                return 'Baixa';
            default:
                return 'Média';
        }
    }
    
    return 'Média'; // Fallback final
};

// Mapear prioridade para CSS class (sempre minúsculo)
const getPriorityCssClass = (priority) => {
    const priorityStr = getPriorityString(priority);
    return priorityStr.toLowerCase(); // Manter acentos: "média" fica "média"
};

// ✅ FUNÇÃO PARA CONVERTER PRIORIDADE PARA ENVIO À API (INT)
const convertPriorityToApi = (priority) => {
    const priorityMap = {
        'Alta': 3,
        'Média': 2,
        'Media': 2,
        'Baixa': 1,
        'Baixo': 1
    };
    
    // Se já é número, retorna como está
    if (typeof priority === 'number') return priority;
    
    // Se é string, converte
    return priorityMap[priority] || 2; // Default: Média = 2
};

// === CONFIGURAÇÃO DE API E MODOS ===
let API_BASE_URL = (() => {
    try {
        const origin = window.location.origin;
        if (origin && !origin.startsWith('file:')) return `${origin}/api`;
    } catch (_) {}
    // Detectar automaticamente se está rodando em 3000 ou 3001
    const currentPort = window.location.port;
    if (currentPort === '3000') {
        return 'http://localhost:3000/api';
    } else if (currentPort === '3001') {
        return 'http://localhost:3001/api';
    }
    // Tentar 3001 primeiro, depois 3000 como fallback
    return 'http://localhost:3001/api';
})();
// MODO FIXO: SEMPRE API REAL - SISTEMA DE PRODUÇÃO
let isApiAvailable = true; // FORÇADO PARA TRUE

console.log('🚀 Sistema iniciado - Modo PRODUÇÃO (apenas dados reais)');
console.log('🔗 URL da API:', API_BASE_URL);

// === FUNÇÕES DE API ===
const apiRequest = async (endpoint, options = {}) => {
    // SEMPRE FAZER REQUISIÇÃO REAL - NUNCA MOCK
    console.log('🚀 API Request:', endpoint, options);
    
    // Tentar múltiplas portas se necessário
    const tryPorts = async (ports) => {
        for (const port of ports) {
            try {
                const baseUrl = `http://localhost:${port}/api`;
                console.log(`📡 Tentando ${baseUrl}${endpoint}`);
                console.log('📤 Enviando dados:', options.body);
                
                const response = await fetch(`${baseUrl}${endpoint}`, {
                    headers: { 'Content-Type': 'application/json', ...options.headers },
                    ...options
                });
                
                console.log('📨 Response status:', response.status, response.statusText);
                
                if (!response.ok) {
                    const errorText = await response.text();
                    console.log('❌ Response error text:', errorText);
                    throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText}`);
                }
                
                // Se chegou aqui, a requisição foi bem-sucedida
                // Atualizar a URL base para futuras requisições
                API_BASE_URL = baseUrl;
                
                const data = await response.json();
                console.log('✅ API Response:', endpoint, data);
                return data;
            } catch (error) {
                console.log(`⚠️ Tentativa na porta ${port} falhou:`, error.message);
                if (port === ports[ports.length - 1]) {
                    // Se for a última porta, relançar o erro
                    throw error;
                }
            }
        }
    };
    
    try {
        // Se API_BASE_URL já está definida, usar diretamente
        if (API_BASE_URL && !API_BASE_URL.includes('undefined')) {
            const response = await fetch(`${API_BASE_URL}${endpoint}`, {
                headers: { 'Content-Type': 'application/json', ...options.headers },
                ...options
            });
            
            if (!response.ok) {
                throw new Error(`HTTP ${response.status}: ${response.statusText}`);
            }
            
            const data = await response.json();
            console.log('✅ API Response:', endpoint, data);
            return data;
        }
        
        // Caso contrário, tentar detectar a porta
        const currentPort = window.location.port;
        // PRIORIZAR PORTA 3001 (PROXY TIMELINE) seguida de 3000 (BACKEND ORIGINAL)
        const ports = currentPort ? [currentPort, '3001', '3000'] : ['3001', '3000'];
        return await tryPorts([...new Set(ports)]); // Remove duplicatas
        
    } catch (error) {
        console.error('❌ API Error:', endpoint, error);
        // REJEITAR ERRO - NÃO PERMITIR FALLBACK
        throw error;
    }
};

// === FUNÇÕES DE CARREGAMENTO DE DADOS ===
const loadUsersFromApi = async () => {
    const result = await apiRequest('/users');
    if (result && result.success) {
        usersCache = result.data || [];
        usersCacheTime = Date.now();
        console.log('👥 Usuários carregados da API:', usersCache.length);
        console.log('📊 Usuários:', usersCache.map(u => `${u.name} (${u.id})`).join(', '));
        return usersCache;
    }
    throw new Error('🚨 ERRO: Falha ao carregar usuários da API - sistema requer banco de dados');
};

// === DETECÇÃO DE USUÁRIO WINDOWS ===
const getCurrentWindowsUser = async () => {
    try {
        console.log('🔍 Detectando usuário Windows...');
        
        // Método 1: Tentar obter do backend via API
        try {
            const response = await fetch('/api/current-user', {
                method: 'GET',
                headers: { 'Accept': 'application/json' }
            });
            
            if (response.ok) {
                const data = await response.json();
                if (data.success && data.user) {
                    console.log('👤 Usuário detectado via API:', data.user);
                    console.log('🎭 Role detectada:', data.role);
                    
                    // Armazenar a role globalmente
                    currentUserRole = data.role || 'colaborador';
                    
                    return data.user;
                }
            }
        } catch (e) {
            console.log('⚠️ API de usuário não disponível na primeira tentativa, tentando novamente...');
            // Tentar novamente com um delay
            await new Promise(resolve => setTimeout(resolve, 1000));
            try {
                const response = await fetch('/api/current-user', {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                });
                
                if (response.ok) {
                    const data = await response.json();
                    if (data.success && data.user) {
                        console.log('👤 Usuário detectado na segunda tentativa:', data.user);
                        currentUserRole = data.role || 'colaborador';
                        return data.user;
                    }
                }
            } catch (e2) {
                console.log('⚠️ Segunda tentativa de API também falhou');
            }
        }
        
        // Método 2: Fallback para usuário conhecido
        console.log('🔄 API não disponível - usando usuário padrão para desenvolvimento');
        const fallbackUser = 'G0040925';
        currentUserRole = getUserRole(fallbackUser); // ✅ Usar função getUserRole
        return fallbackUser;
        
    } catch (error) {
        console.error('❌ Erro ao detectar usuário:', error);
        currentUserRole = 'colaborador';
        return 'G0040925';
    }
};

document.addEventListener('DOMContentLoaded', async () => {
    // Estado global da aplicação
    let currentUser = await getCurrentWindowsUser(); // Detectar usuário Windows automaticamente
    console.log(`🎯 Usuário ativo: ${currentUser}`);
    let currentDemandId = null;
    let timelineModal = null;
    
    // Limites de slots de prioridade (WIP) para demandas em aberto com pontuação Analytics
    // Assunção: até 3 demandas como Alta e até 7 como Média simultaneamente; demais ficam Baixa
    const prioritySlots = { alta: 3, media: 7 };
    let classificationModal = null;
    let redistributeModal = null;

    // Cache para dados da API (apenas dados reais)
    let demandsCache = [];

    // Elementos DOM
    const appContent = document.getElementById('app-content');
    const currentUserNameSpan = document.getElementById('current-user-name');
    const currentUserRoleSpan = document.getElementById('current-user-role');
    const adminPanelNavItem = document.getElementById('nav-admin-panel-item');
    const focalPanelNavItem = document.getElementById('nav-focal-panel-item');

    // Inicializar modais Bootstrap (fallback se bootstrap JS não estiver disponível)
    const hasBootstrap = typeof window.bootstrap !== 'undefined';
    const safeModal = (id) => {
        const el = document.getElementById(id);
        if (!el) return { show: () => {}, hide: () => {} };
        if (hasBootstrap) return new bootstrap.Modal(el);
        return {
            show: () => { el.style.display = 'block'; el.classList.add('show'); el.removeAttribute('aria-hidden'); },
            hide: () => { el.style.display = 'none'; el.classList.remove('show'); el.setAttribute('aria-hidden', 'true'); }
        };
    };
    timelineModal = safeModal('timelineModal');
    classificationModal = safeModal('classificationModal');
    redistributeModal = safeModal('redistributeModal');

    // === EVENT LISTENERS PARA CONTROLE DO AUTO-REFRESH ===
    // Adicionar listeners para parar auto-refresh quando modal timeline for fechado
    const timelineModalEl = document.getElementById('timelineModal');
    if (timelineModalEl) {
        // Listener para quando modal é fechado (tanto por Bootstrap quanto manualmente)
        timelineModalEl.addEventListener('hidden.bs.modal', () => {
            timelineModalOpen = false;
            currentTimelineViewDemandId = null;
            stopAutoRefresh();
            console.log('📴 Timeline modal fechado - auto-refresh parado');
        });
        
        // Listener alternativo para casos sem Bootstrap
        const closeButtons = timelineModalEl.querySelectorAll('[data-bs-dismiss="modal"], .btn-close');
        closeButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                setTimeout(() => {
                    timelineModalOpen = false;
                    currentTimelineViewDemandId = null;
                    stopAutoRefresh();
                    console.log('📴 Timeline modal fechado manualmente - auto-refresh parado');
                }, 300);
            });
        });
        
        // Listener para clique no backdrop
        timelineModalEl.addEventListener('click', (e) => {
            if (e.target === timelineModalEl) {
                setTimeout(() => {
                    timelineModalOpen = false;
                    currentTimelineViewDemandId = null;
                    stopAutoRefresh();
                    console.log('📴 Timeline modal fechado via backdrop - auto-refresh parado');
                }, 300);
            }
        });
    }

    // === FUNÇÕES DE API E DETECÇÃO ===
    const probeApi = async () => {
        try {
            console.log('🔄 Testando conexão com API em:', API_BASE_URL);
            
            // Primeiro teste: health check
            const healthBase = API_BASE_URL.replace(/\/api$/, '');
            const healthResponse = await fetch(`${healthBase}/health`, { 
                method: 'GET',
                cache: 'no-store',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            });
            
            if (!healthResponse.ok) {
                throw new Error(`Health check failed: ${healthResponse.status} ${healthResponse.statusText}`);
            }
            
            const healthData = await healthResponse.json();
            console.log('✅ Health check OK:', healthData);
            
            // Segundo teste: verificar endpoint de usuários
            const usersResponse = await fetch(`${API_BASE_URL}/users`, { 
                method: 'GET',
                cache: 'no-store',
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            });
            
            if (!usersResponse.ok) {
                throw new Error(`Users endpoint failed: ${usersResponse.status} ${usersResponse.statusText}`);
            }
            
            const usersData = await usersResponse.json();
            console.log('✅ API totalmente funcional. Users endpoint OK:', usersData);
            return true;
            
        } catch (error) {
            console.error('🚨 ERRO na detecção da API:', error);
            console.error('🚨 Detalhes completos:', {
                message: error.message,
                stack: error.stack,
                url: API_BASE_URL
            });
            return false;
        }
    };

    const loadDemandsFromApi = async () => {
        const result = await apiRequest('/demands');
        if (result && result.success) {
            demandsCache = result.data || [];
            
            // Mapear priority_score do banco para analyticsScore no frontend
            demandsCache.forEach(demand => {
                if (demand.priority_score !== undefined && demand.priority_score !== null) {
                    demand.analyticsScore = demand.priority_score;
                }
            });
            
            // O backend agora anexa a timeline diretamente. A busca abaixo não é mais necessária.
            // A timeline já está em demand.timeline
            console.log('📋 Demandas carregadas da API com timeline:', demandsCache.length);
            return demandsCache;
        }
        throw new Error('🚨 ERRO: Falha ao carregar demandas da API - sistema requer banco de dados');
    };

    const saveDemandToApi = async (demandData) => {
        return await apiRequest('/demands', {
            method: 'POST',
            body: JSON.stringify(demandData)
        });
    };

    const updateDemandInApi = async (id, updateData) => {
        return await apiRequest(`/demands/${id}`, {
            method: 'PUT',
            body: JSON.stringify(updateData)
        });
    };

    // === INICIALIZAÇÃO E DETECÇÃO DE API ===
    const initializeApp = async () => {
        try {
            console.log('🔄 FORÇANDO modo API - sem detecção automática...');
            // FORÇAR API - IGNORAR DETECÇÃO
            isApiAvailable = true;
            
            if (isApiAvailable) {
                console.log('✅ Modo API FORÇADO - dados reais do banco');
                
                // Carregar dados da API
                await loadUsersFromApi();
                await loadDemandsFromApi();
            } else {
                console.error('� ERRO CRÍTICO: API não disponível! Sistema não pode funcionar sem banco de dados.');
                alert('ERRO: Servidor não está disponível! Verifique se o backend está rodando na porta 3000.');
                throw new Error('API obrigatória não disponível');
            }
        } catch (error) {
            console.error('🚨 ERRO CRÍTICO na conexão com API:', error);
            alert('ERRO CRÍTICO: Não foi possível conectar com o servidor. Sistema requer banco de dados.');
            throw error;
        }
        
        // Inicializar interface
        updateUsersCache(); // Atualizar cache de usuários
        updateUserInfo();
        showSection('home');
        
        // 🆕 INICIAR AUTO-REFRESH GLOBAL DAS LISTAS
        startGlobalAutoRefresh();
        
        // Adicionar indicador visual de auto-refresh
        addRefreshIndicator();
        
        console.log(`🎯 Aplicação iniciada em modo: API EXCLUSIVO com auto-refresh ativo`);
    };

    // === FUNÇÕES DE ACESSO A DADOS (APENAS API REAL) ===
    const getUsers = () => {
        return usersCache || [];
    };

    const getDemands = () => {
        return demandsCache || [];
    };

    const findUserByUsername = (username) => {
        const users = getUsers();
        return users.find(u => u.username === username || u.id === username);
    };

    const saveDemand = async (demandData) => {
        // FORÇAR sempre usar API - NUNCA mock
        if (!isApiAvailable) {
            throw new Error('🚨 ERRO: Sistema requer conexão com banco de dados. API não disponível.');
        }
        
        // Salvar via API OBRIGATORIAMENTE
        console.log('� Salvando demanda no banco de dados via API...');
        const result = await saveDemandToApi(demandData);
        if (result && result.success) {
            console.log('✅ Demanda salva com sucesso no banco:', result.data.id);
            // Recarregar cache
            await loadDemandsFromApi();
            return result;
        }
        throw new Error('Erro ao salvar demanda via API');
    };

    const updateDemand = async (id, updateData) => {
        // FORÇAR sempre usar API - NUNCA mock
        if (!isApiAvailable) {
            throw new Error('🚨 ERRO: Sistema requer conexão com banco de dados. API não disponível.');
        }
        
        // Atualizar via API OBRIGATORIAMENTE
        console.log('💾 Atualizando demanda no banco de dados via API...');
        const result = await updateDemandInApi(id, updateData);
        if (result && result.success) {
            console.log('✅ Demanda atualizada com sucesso no banco:', id);
            // Recarregar cache
            await loadDemandsFromApi();
            return result;
        }
        throw new Error('Erro ao atualizar demanda via API');
    };

    const saveAnalyticsClassification = async (demandId, criteria) => {
        // FORÇAR sempre usar API - NUNCA mock
        if (!isApiAvailable) {
            throw new Error('🚨 ERRO: Sistema requer conexão com banco de dados. API não disponível.');
        }
        
        // Salvar via API OBRIGATORIAMENTE
        console.log('📊 Salvando classificação Analytics no banco de dados via API...');
        const result = await apiRequest(`/demands/${demandId}/analytics-classification`, {
            method: 'POST',
            body: JSON.stringify(criteria)
        });
        
        if (result && result.success) {
            await loadDemandsFromApi();
            return result;
        }
        throw new Error('Erro ao salvar classificação via API');
    };

    // ===== FUNÇÕES AUXILIARES DE FOCAIS =====
    const normalize = (text) => (text || '').toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu, '');

    const findAutoFocalByScenarioOrObservation = (scenario, observation) => {
        // Buscar o responsável do tema selecionado no dropdown
        const scenarioSelect = document.getElementById('scenario');
        if (scenarioSelect && scenarioSelect.selectedIndex > 0) {
            const selectedOption = scenarioSelect.options[scenarioSelect.selectedIndex];
            const responsavel = selectedOption.getAttribute('data-responsavel');
            if (responsavel) {
                console.log('✅ Responsável automático encontrado:', responsavel, 'para tema:', scenario);
                return responsavel;
            }
        }
        
        console.log('⚠️ Nenhum responsável encontrado para tema:', scenario);
        return null;
    };

    // ===== FUNÇÕES DE STATUS =====
    const isStatusConcluido = (status) => {
        const statusLower = (status || '').toLowerCase().trim();
        return statusLower === 'concluída' || statusLower === 'concluido' || statusLower === 'concluído';
    };

    const isStatusCancelado = (status) => {
        const statusLower = (status || '').toLowerCase().trim();
        return statusLower === 'cancelada' || statusLower === 'cancelado';
    };

    const isStatusFinalizado = (status) => {
        return isStatusConcluido(status) || isStatusCancelado(status);
    };

    // ===== FUNÇÕES DE PRAZO =====
    const calculateDeadlineStatus = (createdAt, deadline, status) => {
        if (!deadline) return { status: 'sem-data', text: 'Sem prazo', class: 'prazo-sem-data' };
        
        // ✅ NOVA LÓGICA: Se demanda está concluída ou cancelada, não mostrar análise de prazo
        if (isStatusFinalizado(status)) {
            return { status: 'finalizada', text: status || 'Finalizada', class: 'prazo-finalizada' };
        }
        
        const created = new Date(createdAt);
        const deadlineDate = new Date(deadline);
        const now = new Date();
        
        // Se a demanda foi criada depois do prazo, considerar fora do prazo
        if (created > deadlineDate) {
            return { status: 'fora', text: 'Fora do prazo', class: 'prazo-fora' };
        }
        
        // Se hoje é depois do prazo
        if (now > deadlineDate) {
            return { status: 'fora', text: 'Fora do prazo', class: 'prazo-fora' };
        }
        
        return { status: 'dentro', text: 'Dentro do prazo', class: 'prazo-dentro' };
    };

    const formatDeadline = (deadline) => {
        if (!deadline) return '-';
        return new Date(deadline).toLocaleDateString('pt-BR');
    };

    // ===== PONTUAÇÃO ANALYTICS (INLINE) =====
    const toggleAnalyticsSection = (visible) => {
        const section = document.getElementById('analytics-section');
        if (!section) return;
        section.style.display = visible ? '' : 'none';
        section.querySelectorAll('.classification-select').forEach(el => {
            if (visible) el.setAttribute('required', 'required');
            else el.removeAttribute('required');
        });
    };

    const calculateInlineAnalyticsScore = () => {
        const form = document.getElementById('new-request-form');
        if (!form) return 0;
        const selects = form.querySelectorAll('.classification-select');
        const data = {};
        selects.forEach(s => { data[s.name] = s.value; });
        let score = 0;
        const add123 = (v) => { const n = parseInt(v, 10); if (!isNaN(n)) score += n; };
        add123(data.impacto_cliente_final);
        add123(data.complexidade_tecnica);
        add123(data.tdna);
        add123(data.nps);
        add123(data.reincidencia);
        add123(data.reclamada);
        add123(data.frequencia_automacao);
        if (data.gestao_equipes_direta === 'sim') score += 1;
        if (data.envolvimento_grupos === 'sim') score += 1;
        if (data.gerar_dentro_casa === 'nao') score += 1; // Sim=0, Não=1
        const scoreEl = document.getElementById('calculated-score-inline');
        const levelEl = document.getElementById('priority-level-inline');
        if (scoreEl) scoreEl.textContent = String(score);
        if (levelEl) {
            let txt = 'Baixa'; let cls = 'bg-success';
            if (score >= 18) { txt = 'Alta'; cls = 'bg-danger'; }
            else if (score >= 12) { txt = 'Média'; cls = 'bg-warning'; }
            levelEl.textContent = txt; levelEl.className = `badge ${cls}`;
        }
        return score;
    };

    const getPriorityFromScore = (score) => {
        if (score >= 18) return 'Alta';
        if (score >= 12) return 'Média';
        return 'Baixa';
    };

    // Recalcula prioridades dos itens em aberto com base nas pontuações, respeitando slots
    const recomputePrioritySlots = () => {
        try {
            // Considera demandas não concluídas e não canceladas com pontuação definida
            const isOpen = (status) => !['Concluída', 'Cancelada'].includes(status);
            const analyticsOpen = getDemands()
                .filter(d => (d.analyticsScore || d.analyticsScore === 0) && isOpen(d.status))
                .sort((a, b) => (b.analyticsScore || 0) - (a.analyticsScore || 0));

            // Aplica slots Alta e Média, o restante Baixa
            analyticsOpen.forEach((demand, index) => {
                if (index < prioritySlots.alta) {
                    demand.priority = 'Alta';
                } else if (index < prioritySlots.alta + prioritySlots.media) {
                    demand.priority = 'Média';
                } else {
                    demand.priority = 'Baixa';
                }
            });

            // Para demandas sem analyticsScore definido, mantém prioridade existente ou deriva por score inline se existir
            getDemands().forEach(d => {
                if (!(d.analyticsScore || d.analyticsScore === 0)) {
                    if (!d.priority) {
                        d.priority = 'Média';
                    }
                }
            });
        } catch (e) {
            console.error('Erro ao recomputar slots de prioridade:', e);
        }
    };

    // Calcula o ranking por Focal (responsável): para cada responsável, ordena por maior analyticsScore
    const buildFocalRankMap = () => {
        const byFocal = new Map(); // username -> demanda[]
        (getDemands() || []).forEach(d => {
            if (!d || !d.responsible) return;
            if (!(d.analyticsScore || d.analyticsScore === 0)) return;
            if (!byFocal.has(d.responsible)) byFocal.set(d.responsible, []);
            byFocal.get(d.responsible).push(d);
        });
        const rankById = new Map();
        byFocal.forEach(list => {
            list.sort((a, b) => (b.analyticsScore || 0) - (a.analyticsScore || 0) || a.id - b.id);
            list.forEach((d, i) => rankById.set(d.id, i + 1));
        });
        return rankById;
    };

    // Calcula ranking geral por responsável (SEPARA Analytics das outras demandas)
    const buildGeneralRankMap = () => {
        const byFocal = new Map(); // username -> { analytics: [], others: [] }
        (getDemands() || []).forEach(d => {
            if (!d || !d.responsible) return;
            
            // ✅ IMPORTANTE: Só incluir demandas que tenham pontuação válida
            const hasValidScore = d.analyticsScore !== null && d.analyticsScore !== undefined && d.analyticsScore >= 0;
            if (!hasValidScore) return;
            
            if (!byFocal.has(d.responsible)) byFocal.set(d.responsible, { analytics: [], others: [] });
            
            // Verificar CENÁRIO para determinar se é Analytics
            const isAnalyticsScenario = d.scenario?.toLowerCase().includes('analytics') || 
                                      d.scenario === 'Analytics Prioridade';
            
            if (isAnalyticsScenario) {
                byFocal.get(d.responsible).analytics.push(d);
            } else {
                byFocal.get(d.responsible).others.push(d);
            }
        });
        
        const rankById = new Map();
        byFocal.forEach(lists => {
            // ✅ CORREÇÃO: AMBOS rankings ordenados por pontuação (maior primeiro)
            lists.analytics.sort((a, b) => (b.analyticsScore || 0) - (a.analyticsScore || 0) || a.id - b.id);
            lists.others.sort((a, b) => (b.analyticsScore || 0) - (a.analyticsScore || 0) || a.id - b.id); // ✅ MUDANÇA: era por ID, agora por score
            
            // Posições: Analytics com prefixo A1, A2, A3... e Gerais com prefixo G1, G2, G3...
            lists.analytics.forEach((d, i) => rankById.set(d.id, `A${i + 1}`));
            lists.others.forEach((d, i) => rankById.set(d.id, `G${i + 1}`));
        });
        return rankById;
    };

    // ✅ FUNÇÃO PARA CRIAR BADGE DE RANKING POR CATEGORIA (Op1, Ql2, An3, etc.)
    const createRankBadge = (rank) => {
        if (rank === '-') return '-';
        
        // Extrair sigla e número (ex: Op1, Ql2, An3)
        const match = typeof rank === 'string' ? rank.match(/^([A-Z][a-z])(\d+)$/) : null;
        
        if (match) {
            const [, sigla, numero] = match;
            const number = parseInt(numero);
            const rankClass = number <= 3 ? `rank-${number}` : '';
            
            // Cores por categoria
            const categoryColors = {
                'Op': '#3b82f6', // Azul - Operacional
                'Ql': '#10b981', // Verde - Qualidade  
                'An': '#8b5cf6', // Roxo - Analytics
                'Pr': '#eab308', // Amarelo - Processos
                'Pj': '#ef4444', // Vermelho - Projetos
                'Ot': '#6b7280'  // Cinza - Outros
            };
            
            const color = categoryColors[sigla] || '#6b7280';
            
            return `<span class="badge badge-rank ${rankClass}" style="background: ${color}; color: white; font-weight: bold;">${rank}</span>`;
        }
        
        // Fallback para rankings antigos (A1, G2, etc.)
        const isAnalytics = typeof rank === 'string' && rank.startsWith('A');
        const isGeneral = typeof rank === 'string' && rank.startsWith('G');
        
        if (isAnalytics || isGeneral) {
            const number = parseInt(rank.substring(1));
            const rankClass = number <= 3 ? `rank-${number}` : '';
            return `<span class="badge badge-rank ${rankClass}">${rank}</span>`;
        }
        
        // Fallback para rankings numéricos
        const rankClass = rank <= 3 ? `rank-${rank}` : '';
        return `<span class="badge badge-rank ${rankClass}">${rank}</span>`;
    };

    // ===== FUNÇÕES DE RENDERIZAÇÃO =====

    // Estado da Home (filtros)
    let homeStatusFilter = 'all';

    // Homepage com capa/hero e métricas
    const initHomeCarousel = () => {
        const el = document.getElementById('homeCarousel');
        if (!el) return;
        if (window.bootstrap && bootstrap.Carousel) {
            try {
                new bootstrap.Carousel(el, { interval: 3000, ride: 'carousel', pause: false, touch: true, wrap: true });
            } catch (e) { /* ignore */ }
        } else {
            // Fallback: alterna manualmente as imagens
            const items = el.querySelectorAll('.carousel-item');
            if (!items || items.length === 0) return;
            let idx = 0;
            items.forEach((it, i) => it.classList.toggle('active', i === 0));
            setInterval(() => {
                items[idx].classList.remove('active');
                idx = (idx + 1) % items.length;
                items[idx].classList.add('active');
            }, 3000);
        }
    };

    const renderHome = async () => {
        // Garantir que dados estão carregados antes de renderizar
        if (demandsCache.length === 0) {
            try {
                await loadDemandsFromApi();
            } catch (error) {
                console.error('🚨 Erro ao carregar demandas para renderHome:', error);
            }
        }
        
        const user = findUserByUsername(currentUser) || { role: currentUserRole };
        const userRole = currentUserRole; // Usar role detectada pela API
        const today = new Date().toISOString().split('T')[0];

        // Garante prioridades consistentes ao entrar na Home
        recomputePrioritySlots();

        // Filtrar demandas conforme hierarquia
        const baseDemands = getDemands().filter(d => {
            if (userRole === 'admin') return true;
            if (hasFocalPermissions(userRole)) return d.responsible === currentUser;
            return d.requester === currentUser;
        });

        const totalDemands = baseDemands.length;
        const inProgress = baseDemands.filter(d => ['Em andamento','Em análise','Aguardando retorno ( demandante)','Aguardando aprovação','Aberta'].includes(d.status)).length;
        const dueTodayDemands = baseDemands.filter(d => d.deadline === today);
        const dueToday = dueTodayDemands.length;

        const statusOptions = ['Todos','Aberta','Aguardando aprovação','Aguardando retorno ( demandante)','Cancelada','Concluída','Em análise','Em andamento'];

        // Demandas do usuário para o bloco "Minhas Demandas" - CORRIGIDO para incluir como solicitante OU responsável
        const myAllDemands = getDemands().filter(d => 
            d.requester === currentUser || d.responsible === currentUser
        );
        const myFiltered = myAllDemands.filter(d => {
            if (homeStatusFilter === 'all') return true;
            return d.status === homeStatusFilter;
        });

        appContent.innerHTML = `
            <section class="hero-section mb-4">
                <div class="row align-items-center g-4">
                    <div class="col-lg-7">
                        <h1 class="display-5 fw-bold text-dark mb-3">Gestão de Demandas Governança TOP</h1>
                        <p class="text-muted mb-4">Centralize, priorize e acompanhe suas solicitações direcionadas para a equipe de Governança.</p>
                        <div class="d-flex gap-2 flex-wrap">
                            <button id="btn-new-request" class="btn btn-primary" data-action="new-request"><i class="fas fa-plus me-1"></i>Nova Demanda</button>
                            <button class="btn btn-outline-primary" data-action="my-requests"><i class="fas fa-list me-1"></i>Ver Demandas</button>
                            <button class="btn btn-success" onclick="exportToExcel()"><i class="fas fa-file-excel me-1"></i>Exportar Excel</button>
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div id="homeCarousel" class="carousel slide hero-carousel" data-bs-ride="carousel">
                            <div class="carousel-indicators">
                                <button type="button" data-bs-target="#homeCarousel" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                                <button type="button" data-bs-target="#homeCarousel" data-bs-slide-to="1" aria-label="Slide 2"></button>
                                <button type="button" data-bs-target="#homeCarousel" data-bs-slide-to="2" aria-label="Slide 3"></button>
                            </div>
                            <div class="carousel-inner">
                                <div class="carousel-item active">
                                    <img src="https://vivomeunegocio.com.br/wp-content/uploads/2024/11/softwares-gratuitos-pc-660x450.png" class="d-block w-100" alt="Ambiente de escritório" />
                                </div>
                                <div class="carousel-item">
                                    <img src="https://vivomeunegocio.com.br/wp-content/uploads/2024/12/1200x675-2-660x450.png" class="d-block w-100" alt="Tecnologia e telecom" />
                                </div>
                                <div class="carousel-item">
                                    <img src="https://images.unsplash.com/photo-1521737604893-d14cc237f11d?auto=format&fit=crop&w=1200&q=60" class="d-block w-100" alt="Equipes colaborando" />
                                </div>
                            </div>
                            <button class="carousel-control-prev" type="button" data-bs-target="#homeCarousel" data-bs-slide="prev">
                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Anterior</span>
                            </button>
                            <button class="carousel-control-next" type="button" data-bs-target="#homeCarousel" data-bs-slide="next">
                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                <span class="visually-hidden">Próximo</span>
                            </button>
                        </div>
                    </div>
                </div>
            </section>

            <div class="row g-3 mb-4 align-items-stretch metrics-row-equal">
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="card metric-card compact h-100 w-100">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div>
                                <div class="metric-title">Demandas Abertas</div>
                                <div class="metric-value">${totalDemands}</div>
                                <small class="text-muted">De acordo com seu perfil</small>
                            </div>
                            <div class="metric-icon bg-primary-subtle text-primary"><i class="fas fa-inbox"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="card metric-card compact h-100 w-100">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div>
                                <div class="metric-title">Em Andamento</div>
                                <div class="metric-value">${inProgress}</div>
                                <small class="text-muted">Inclui pendentes/análise</small>
                            </div>
                            <div class="metric-icon bg-warning-subtle text-warning"><i class="fas fa-rotate"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="card metric-card compact h-100 w-100">
                        <div class="card-body d-flex align-items-center justify-content-between">
                            <div>
                                <div class="metric-title">Prazo Hoje</div>
                                <div class="metric-value">${dueToday}</div>
                                <small class="text-muted">Conforme seu perfil</small>
                            </div>
                            <div class="metric-icon bg-danger-subtle text-danger"><i class="fas fa-calendar-day"></i></div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 d-flex">
                    <div class="card metric-card compact quick-actions-card h-100 w-100">
                        <div class="card-header"><strong>Ações rápidas</strong></div>
                        <div class="card-body d-grid gap-2">
                            <button class="btn btn-sm btn-outline-primary w-100" data-action="goto-focal">Atribuídas</button>
                            <button class="btn btn-sm btn-outline-secondary w-100" data-action="goto-general">Demandas Gerais</button>
                        </div>
                    </div>
                </div>
            </div>

            ${dueToday > 0 ? `
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-bell me-2 text-danger"></i>Demandas com prazo hoje</h5>
                    <small class="text-muted">${userRole === 'admin' ? 'Todas' : hasFocalPermissions(userRole) ? 'Atribuídas a você' : 'Suas solicitações'}</small>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                                                                <table class="table table-hover">
                                            <thead>
                                                <tr><th>ID Sistema</th><th>ID Real</th><th>Grupo</th><th>Cenário</th><th>Submotivo</th><th>Status</th><th>Prazo</th><th>Responsável</th></tr>
                                            </thead>
                                            <tbody>
                                                ${dueTodayDemands.map(d => `
                                                    <tr>
                                                        <td><strong>#${d.id}</strong></td>
                                                        <td><span class="badge bg-info text-dark">${d.real_demand_id || 'N/A'}</span></td>
                                                        <td><small>${d.group_name || d.group || 'N/A'}</small></td>
                                                        <td><small>${d.scenario}</small></td>
                                                        <td><small class="text-primary">${d.submotivo || 'N/A'}</small></td>
                                                        <td><span class="badge status-badge status-${(d.status || 'novo').toLowerCase().replace(' ', '-')}">${d.status || 'Novo'}</span></td>
                                                        <td><small>${formatDeadline(d.deadline)}</small></td>
                                                        <td><small>${d.responsible ? getUserName(d.responsible) : '-'}</small></td>
                                                    </tr>
                                                `).join('')}
                                            </tbody>
                                        </table>
                    </div>
                </div>
            </div>
            ` : ''}

            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Minhas Demandas</h5>
                    <div class="d-flex align-items-center gap-2">
                        <label for="home-status-filter" class="form-label mb-0">Status:</label>
                        <select id="home-status-filter" class="form-select form-select-sm" style="width:auto">
                            ${statusOptions.map(opt => {
                                const value = opt === 'Todos' ? 'all' : opt;
                                const sel = (value === homeStatusFilter) ? 'selected' : '';
                                return `<option value="${value}" ${sel}>${opt}</option>`;
                            }).join('')}
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <div class="table-responsive table-scroll">
                        <table class="table table-hover">
                            <thead>
                                <tr><th>ID Sistema</th><th>ID Real</th><th>Grupo</th><th>Cenário</th><th>Submotivo</th><th>Status</th><th>Prazo</th><th>Prioridade</th></tr>
                            </thead>
                            <tbody>
                                ${myFiltered.map(d => `
                                    <tr>
                                        <td><strong>#${d.id}</strong></td>
                                        <td><span class="badge bg-info text-dark">${d.real_demand_id || 'N/A'}</span></td>
                                        <td><small>${d.group_name || d.group || 'N/A'}</small></td>
                                        <td><small>${d.scenario}</small></td>
                                        <td><small class="text-primary">${d.submotivo || 'N/A'}</small></td>
                                        <td><span class="badge status-badge status-${(d.status || 'novo').toLowerCase().replace(' ', '-')}">${d.status || 'Novo'}</span></td>
                                        <td><small>${formatDeadline(d.deadline)}</small></td>
                                        <td><span class="badge priority-${getPriorityCssClass(d.priority)}">${getPriorityString(d.priority)}</span></td>
                                    </tr>
                                `).join('') || '<tr><td colspan="8" class="text-muted text-center">Sem demandas</td></tr>'}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        `;

        // Bind seguro dos botões (caso o inline falhe)
        document.getElementById('btn-new-request')?.addEventListener('click', () => window.gotoNewRequest && window.gotoNewRequest());

        // Inicializa o carrossel (com fallback sem Bootstrap JS)
        initHomeCarousel();

        // Listener do filtro de status (home)
        document.getElementById('home-status-filter')?.addEventListener('change', (e) => {
            homeStatusFilter = e.target.value;
            renderHome();
        });
    };

    const renderNewRequestForm = async () => {
        // Carregar temas dinamicamente da API
        let scenarioOptions = '';
        try {
            // Primeiro, garantir que os usuários estão carregados
            if (!usersCache || usersCache.length === 0) {
                await loadUsersFromApi();
            }
            
            const temasResult = await apiRequest('/temas');
            if (temasResult && temasResult.success) {
                const temas = temasResult.data.sort((a, b) => a.tema.localeCompare(b.tema, 'pt-BR', { sensitivity: 'base' }));
                scenarioOptions = temas
                    .map(t => {
                        // Resolver nome do responsável
                        const responsavelNome = getUserName(t.usuario_windows) || t.focal_nome || t.usuario_windows;
                        return `<option value="${t.tema}" data-glossario="${t.glossario || ''}" data-responsavel="${t.usuario_windows}" data-responsavel-nome="${responsavelNome}">${t.tema}</option>`;
                    })
                    .join('');
            } else {
                // Fallback para lista estática se API não funcionar (temas exatos da planilha)
                const scenarioTopics = [
                    'Análises de eficiência',
                    'Apoio operacional',
                    'Automações',
                    'Controles operacionais',
                    'Diagnóstico Qualitativo',
                    'Diagnóstico Quantitativo',
                    'NPS',
                    'Oportunidades em relatatório de Analytics',
                    'Processos Fixa',
                    'Processos Móvel',
                    'Projetos',
                    'Quartis',
                    'Rechamada',
                    'Reincidência',
                    'Reports recorrentes',
                    'Retratação',
                    'TDNA',
                    'TOP Care',
                    'WDE',
                    'Whisper',
                    'Outros'
                ];
                scenarioOptions = scenarioTopics
                    .slice()
                    .sort((a,b) => a.localeCompare(b, 'pt-BR', { sensitivity: 'base' }))
                    .map(t => `<option value="${t}">${t}</option>`) 
                    .join('');
            }
        } catch (error) {
            console.error('Erro ao carregar temas:', error);
            // Fallback (temas exatos da planilha)
            const scenarioTopics = [
                'Análises de eficiência',
                'Apoio operacional',
                'Automações',
                'Controles operacionais',
                'Diagnóstico Qualitativo',
                'Diagnóstico Quantitativo',
                'NPS',
                'Oportunidades em relatatório de Analytics',
                'Processos Fixa',
                'Processos Móvel',
                'Projetos',
                'Quartis',
                'Rechamada',
                'Reincidência',
                'Reports recorrentes',
                'Retratação',
                'TDNA',
                'TOP Care',
                'WDE',
                'Whisper',
                'Outros'
            ];
            scenarioOptions = scenarioTopics
                .slice()
                .sort((a,b) => a.localeCompare(b, 'pt-BR', { sensitivity: 'base' }))
                .map(t => `<option value="${t}">${t}</option>`) 
                .join('');
        }

        appContent.innerHTML = `
            <div class="row justify-content-center">
                <div class="col-lg-10">
                    <div class="card shadow-sm border-0">
                        <div class="card-header bg-white border-bottom">
                            <h4 class="mb-0 text-dark"><i class="fas fa-plus-circle me-2 text-primary"></i>Nova Demanda</h4>
                        </div>
                        <div class="card-body">
                            <form id="new-request-form">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="group" class="form-label text-muted"><i class="fas fa-users me-1"></i>Grupo Solicitante</label>
                                            <select class="form-select border-light" id="group" required>
                                                <option value="" disabled selected>Selecione o grupo...</option>
                                                <option value="TOP">TOP</option>
                                                <option value="TOP+">TOP+</option>
                                                <option value="Associacao">Associação</option>
                                                <option value="Suporte ao GN">Suporte ao GN</option>
                                                <option value="Fidelizar">Fidelizar</option>
                                                <option value="Minhas solicitacoes">Minhas solicitações</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="scenario" class="form-label text-muted"><i class="fas fa-tasks me-1"></i>Tema da Demanda</label>
                                            <select class="form-select border-light" id="scenario" required>
                                                <option value="" disabled selected>Selecione o tema...</option>
                                                ${scenarioOptions}
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- ✅ NOVOS CAMPOS: Data de Abertura, ID Demanda Real e Submotivo -->
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="demand-open-date" class="form-label text-muted"><i class="fas fa-calendar me-1"></i>Data de Abertura da Demanda <small class="text-muted">(Opcional)</small></label>
                                            <input type="date" class="form-control border-light" id="demand-open-date" max="2025-09-03">
                                            <div class="form-text">📅 <strong>Opcional:</strong> Se souber a data real de abertura. Caso contrário, pode pular este campo.</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="real-demand-id" class="form-label text-muted"><i class="fas fa-hashtag me-1"></i>ID da Demanda Real <small class="text-muted">(Opcional)</small></label>
                                            <input type="text" class="form-control border-light" id="real-demand-id" placeholder="Ex: DEM-2024-001">
                                            <div class="form-text">🆔 <strong>Opcional:</strong> Se tiver o ID original do sistema fonte. Pode ser preenchido depois pelos focais/administradores.</div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="mb-3">
                                            <label for="submotivo" class="form-label text-muted"><i class="fas fa-tag me-1"></i>Submotivo</label>
                                            <input type="text" class="form-control border-light" id="submotivo" placeholder="Ex: Análise performance, Automação relatório..." required maxlength="50">
                                            <div class="form-text"><strong>⚡ Seja breve e sucinto!</strong> Não utilize resumo, apenas o submotivo específico (máx. 50 caracteres)</div>
                                        </div>
                                    </div>
                                </div>
                                
                                <!-- Glossário/Direcionamento do Tema -->
                                <div id="tema-glossario" class="mb-3" style="display: none;">
                                    <div class="alert alert-info border-info">
                                        <div class="d-flex align-items-start">
                                            <i class="fas fa-info-circle me-2 mt-1 text-info"></i>
                                            <div>
                                                <strong>Direcionamento para este tema:</strong>
                                                <div id="tema-glossario-text" class="mt-1"></div>
                                                <small class="text-muted mt-2 d-block">
                                                    <i class="fas fa-user me-1"></i>Responsável: <span id="tema-responsavel"></span>
                                                </small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="mb-3">
                                    <label for="observation" class="form-label text-muted"><i class="fas fa-comment me-1"></i>Observação</label>
                                    <textarea class="form-control border-light" id="observation" rows="4" placeholder="Descreva detalhadamente o cenário solicitado..." required></textarea>
                                </div>
                                <!-- Seção de Classificação (agora para todas as entradas) -->
                                <div id="analytics-section">
                                    <hr class="my-4">
                                    <h5 class="mb-3 text-primary"><i class="fas fa-chart-line me-2"></i>Pontuação para Ranking</h5>
                                    <div class="alert alert-light border">
                                        <small class="text-muted">
                                            <strong>Regras:</strong> 1-7 somam 1..3; 8-9 Sim=1/Não=0; 10 Sim=0/Não=1. Máximo: 24 pontos.
                                        </small>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label text-muted">1. Impacto no cliente final: Qual é o impacto no cliente final?</label>
                                                <select class="form-select classification-select border-light" name="impacto_cliente_final">
                                                    <option value="">Selecione...</option>
                                                    <option value="1">1 - Baixo</option>
                                                    <option value="2">2 - Médio</option>
                                                    <option value="3">3 - Alto</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label text-muted">2. Complexidade técnica para entrega: Qual é a complexidade técnica para a entrega?</label>
                                                <select class="form-select classification-select border-light" name="complexidade_tecnica">
                                                    <option value="">Selecione...</option>
                                                    <option value="1">1 - Baixa</option>
                                                    <option value="2">2 - Média</option>
                                                    <option value="3">3 - Alta</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label text-muted">3. TDNA: Qual é o impacto no TDNA?</label>
                                                <select class="form-select classification-select border-light" name="tdna">
                                                    <option value="">Selecione...</option>
                                                    <option value="1">1 - Baixo</option>
                                                    <option value="2">2 - Médio</option>
                                                    <option value="3">3 - Alto</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label text-muted">4. NPS: Qual é o impacto no NPS?</label>
                                                <select class="form-select classification-select border-light" name="nps">
                                                    <option value="">Selecione...</option>
                                                    <option value="1">1 - Baixo</option>
                                                    <option value="2">2 - Médio</option>
                                                    <option value="3">3 - Alto</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label text-muted">5. Reincidência: Qual é o impacto na reincidência?</label>
                                                <select class="form-select classification-select border-light" name="reincidencia">
                                                    <option value="">Selecione...</option>
                                                    <option value="1">1 - Baixa</option>
                                                    <option value="2">2 - Média</option>
                                                    <option value="3">3 - Alta</option>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label text-muted">6. Rechamada: Qual é o impacto na Rechamada?</label>
                                                <select class="form-select classification-select border-light" name="reclamada">
                                                    <option value="">Selecione...</option>
                                                    <option value="1">1 - Baixa</option>
                                                    <option value="2">2 - Média</option>
                                                    <option value="3">3 - Alta</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label text-muted">7. Frequência Automação: A automação/Frequência será pontual ou recorrente?</label>
                                                <select class="form-select classification-select border-light" name="frequencia_automacao">
                                                    <option value="">Selecione...</option>
                                                    <option value="1">1 - Baixa</option>
                                                    <option value="2">2 - Média</option>
                                                    <option value="3">3 - Alta</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label text-muted">8. Gestão equipes direta nos times: Qual é o impacto na gestão dos times?</label>
                                                <select class="form-select classification-select border-light" name="gestao_equipes_direta">
                                                    <option value="">Selecione...</option>
                                                    <option value="sim">Sim (1)</option>
                                                    <option value="nao">Não (0)</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label text-muted">9. Envolvimento de todos os grupos: A demanda envolve todos os grupos?</label>
                                                <select class="form-select classification-select border-light" name="envolvimento_grupos">
                                                    <option value="">Selecione...</option>
                                                    <option value="sim">Sim (1)</option>
                                                    <option value="nao">Não (0)</option>
                                                </select>
                                            </div>
                                            <div class="mb-3">
                                                <label class="form-label text-muted">10. Possível gerar dentro de casa?: É possível realizar a entrega internamente?</label>
                                                <select class="form-select classification-select border-light" name="gerar_dentro_casa">
                                                    <option value="">Selecione...</option>
                                                    <option value="sim">Sim (0)</option>
                                                    <option value="nao">Não (1)</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="mt-3">
                                        <div class="card bg-light border-0">
                                            <div class="card-body d-flex justify-content-between align-items-center">
                                                <div>
                                                    <strong class="text-muted">Pontuação Calculada:</strong> <span id="calculated-score-inline" class="text-primary">0</span> / 24
                                                </div>
                                                <div>
                                                    <span class="badge bg-secondary" id="priority-level-inline">Baixa</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="d-grid gap-2 d-md-flex justify-content-md-end mt-4">
                                    <button type="button" class="btn btn-outline-secondary me-md-2" data-action="my-requests">
                                        <i class="fas fa-times me-1"></i>Cancelar
                                    </button>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-paper-plane me-1"></i>Enviar Demanda
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // ✅ CONFIGURAR LIMITE MÁXIMO PARA DATA (NÃO PERMITIR FUTURAS)
        const today = new Date();
        const todayString = today.getFullYear() + '-' + 
                           String(today.getMonth() + 1).padStart(2, '0') + '-' + 
                           String(today.getDate()).padStart(2, '0');
        
        const demandOpenDateField = document.getElementById('demand-open-date');
        if (demandOpenDateField) {
            demandOpenDateField.max = todayString; // Não permitir datas futuras
            demandOpenDateField.placeholder = 'Opcional - data real de abertura';
        }

        // Eventos do formulário
        const form = document.getElementById('new-request-form');
        form.addEventListener('submit', handleNewRequest);

        // Sempre calcular em tempo real (para todas as entradas)
        form.querySelectorAll('.classification-select').forEach(s => s.addEventListener('change', calculateInlineAnalyticsScore));
        
        // ✅ INICIALIZAR: Mostrar seção de pontuação por padrão (para todos os cenários)
        toggleAnalyticsSection(true);
        
        // Event listener para mostrar glossário quando tema for selecionado
        const scenarioSelect = document.getElementById('scenario');
        scenarioSelect.addEventListener('change', async (e) => {
            const selectedTema = e.target.value;
            const glossarioDiv = document.getElementById('tema-glossario');
            const glossarioText = document.getElementById('tema-glossario-text');
            const responsavelSpan = document.getElementById('tema-responsavel');
            
            // ✅ SEMPRE MOSTRAR SEÇÃO DE PONTUAÇÃO (para todos os cenários)
            // A pontuação é usada tanto para ranking Analytics (A) quanto Gerais (G)
            toggleAnalyticsSection(true);
            
            // Calcular pontuação inicial sempre
            setTimeout(() => {
                calculateInlineAnalyticsScore();
            }, 100); // Pequeno delay para garantir que os elementos estejam prontos
            
            if (selectedTema) {
                // Buscar glossário no próprio option (se veio da API)
                const selectedOption = e.target.options[e.target.selectedIndex];
                const glossario = selectedOption.getAttribute('data-glossario');
                const responsavel = selectedOption.getAttribute('data-responsavel');
                const responsavelNome = selectedOption.getAttribute('data-responsavel-nome');
                
                if (glossario) {
                    glossarioText.textContent = glossario;
                    responsavelSpan.textContent = responsavelNome || getUserName(responsavel) || responsavel;
                    glossarioDiv.style.display = 'block';
                } else {
                    // Fallback: buscar da API
                    try {
                        const result = await apiRequest(`/temas/${encodeURIComponent(selectedTema)}`);
                        if (result && result.success && result.data) {
                            glossarioText.textContent = result.data.glossario || 'Nenhuma informação adicional disponível.';
                            responsavelSpan.textContent = getUserName(result.data.usuario_windows) || result.data.focal_nome || result.data.usuario_windows || 'Não informado';
                            glossarioDiv.style.display = 'block';
                        } else {
                            glossarioDiv.style.display = 'none';
                        }
                    } catch (error) {
                        console.error('Erro ao buscar glossário:', error);
                        glossarioDiv.style.display = 'none';
                    }
                }
            } else {
                glossarioDiv.style.display = 'none';
            }
        });
    };

    const renderMyRequests = async () => {
        const statusOptions = ['Todos','Aberta','Aguardando aprovação','Aguardando retorno ( demandante)','Cancelada','Concluída','Em análise','Em andamento'];
        const selected = document.getElementById('my-requests-status-filter')?.value || 'all';
        
        // CORREÇÃO: Minhas demandas = onde sou solicitante OU responsável
        const allDemands = getDemands().filter(demand => {
            const isRequester = demand.requester === currentUser;
            const isResponsible = demand.responsible === currentUser;
            const matches = isRequester || isResponsible;
            
            // Log detalhado para debug (apenas primeiras 5 demandas)
            if (demand.id <= 5) {
                console.log(`🔍 Debug Demanda #${demand.id}:`);
                console.log(`   - Solicitante (requester): "${demand.requester}"`);
                console.log(`   - Responsável (responsible): "${demand.responsible}"`);
                console.log(`   - Usuário atual (currentUser): "${currentUser}"`);
                console.log(`   - É solicitante?: ${isRequester}`);
                console.log(`   - É responsável?: ${isResponsible}`);
                console.log(`   - Incluir na lista?: ${matches}`);
                console.log('   ---');
            }
            
            return matches;
        });
        
        console.log(`📋 Total de demandas: ${getDemands().length}`);
        console.log(`👤 Usuário atual: ${currentUser}`);
        console.log(`📝 Minhas demandas encontradas: ${allDemands.length}`);
        
        const userDemands = allDemands
            .filter(d => selected === 'all' ? true : d.status === selected)
            .sort((a, b) => (b.analyticsScore ?? -1) - (a.analyticsScore ?? -1) || a.id - b.id);
        
        // Verificar permissões do usuário
        const permissions = await getUserPermissions(currentUser);
        console.log('🔍 Renderizando Minhas Demandas - Permissões:', permissions);
        const exportButton = permissions.canExport ? 
            '<button class="btn btn-success btn-sm" onclick="exportToExcel()"><i class="fas fa-file-excel me-1"></i>Exportar Excel</button>' : '';
        
        console.log('🔘 Botão de export será exibido?', permissions.canExport, exportButton ? 'SIM' : 'NÃO');
        
        appContent.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-list me-2"></i>Minhas Demandas</h2>
                <div class="d-flex align-items-center gap-2">
                    <label class="form-label mb-0" for="my-requests-status-filter">Status:</label>
                    <select id="my-requests-status-filter" class="form-select form-select-sm" style="width:auto">
                        ${statusOptions.map(opt => {
                            const value = opt === 'Todos' ? 'all' : opt; const sel = value === selected ? 'selected' : ''; return `<option value="${value}" ${sel}>${opt}</option>`;
                        }).join('')}
                    </select>
                    ${exportButton}
                    <button class="btn btn-primary" data-action="new-request"><i class="fas fa-plus me-1"></i>Nova Demanda</button>
                </div>
            </div>
            ${userDemands.length === 0 ? 
                `<div class="text-center py-5">
                    <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">Nenhuma demanda encontrada</h4>
                    <p class="text-muted">Você ainda não possui demandas abertas.</p>
                    <button class="btn btn-primary" data-action="new-request"><i class="fas fa-plus me-1"></i>Criar Primeira Demanda</button>
                </div>` :
                `<div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Ranking</th><th>ID Sistema</th><th>ID Real</th><th>Grupo</th><th>Cenário</th><th>Submotivo</th><th>Resumo</th><th>Status</th><th>Prioridade</th><th>Data Abertura</th><th>Aging</th><th>Responsável</th><th>Prazo</th><th>Status Prazo</th><th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${userDemands.map(demand => {
                                const deadlineStatus = calculateDeadlineStatus(demand.createdAt, demand.deadline, demand.status);
                                
                                // ✅ USAR RANKING POR CATEGORIA (Op1, Ql2, An3, etc.)
                                const categoryRanking = buildCategoryRankingMap();
                                const rank = categoryRanking.get(demand.id) || '-';
                                
                                // ✅ CORREÇÃO: Adicionar resumo da observação
                                const resumo = (demand.observation || demand.description || '').substring(0, 45);
                                const resumoTexto = resumo.length > 0 ? (resumo.length === 45 ? resumo + '...' : resumo) : 'Sem descrição';
                                
                                const rankBadge = createRankBadge(rank);
                                return `
                                    <tr>
                                        <td>${rankBadge}</td>
                                        <td><strong>#${demand.id}</strong></td>
                                        <td><span class="badge bg-info text-dark">${demand.real_demand_id || 'N/A'}</span></td>
                                        <td><small>${demand.group_name || demand.group || 'N/A'}</small></td>
                                        <td><small>${demand.scenario}</small></td>
                                        <td><small class="text-primary">${demand.submotivo || 'N/A'}</small></td>
                                        <td><small class="text-muted">${resumoTexto}</small></td>
                                        <td><span class="badge status-badge status-${(demand.status || 'novo').toLowerCase().replace(' ', '-')}">${demand.status || 'Novo'}</span></td>
                                        <td>
                                            <span class="badge priority-${getPriorityCssClass(demand.priority)}">${getPriorityString(demand.priority)}</span>
                                            <small class="text-primary ms-1">(${demand.analyticsScore || 0}pts)</small>
                                        </td>
                                        <td><small>${formatDate(demand.open_date || demand.created_at || demand.createdAt)}</small></td>
                                        <td><small>${calculateAging(demand.open_date || demand.created_at || demand.createdAt)}</small></td>
                                        <td><small>${demand.responsible_name || getUserName(demand.responsible) || '-'}</small></td>
                                        <td><small>${formatDeadline(demand.deadline)}</small></td>
                                        <td><span class="badge ${deadlineStatus.class}">${deadlineStatus.text}</span></td>
                                        <td>
                                            <div class="btn-group" role="group" aria-label="Ações da demanda">
                                                <button class="btn btn-sm btn-outline-primary" data-action="view-timeline" data-id="${demand.id}" title="Ver timeline da demanda">
                                                    <i class="fas fa-eye"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-warning" data-action="edit-demand-id" data-id="${demand.id}" title="🔶 Editar ID Real">
                                                    <i class="fas fa-hashtag"></i>
                                                </button>
                                                <button class="btn btn-sm btn-outline-info" data-action="edit-demand-date" data-id="${demand.id}" title="🔷 Editar Data de Abertura">
                                                    <i class="fas fa-calendar"></i>
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>`
            }
        `;

        // Listener do filtro
        document.getElementById('my-requests-status-filter')?.addEventListener('change', () => renderMyRequests());
    };

    // Renderizar painel focal (demandas atribuídas)
    const renderFocalPanel = async () => {
        // Atualiza prioridades antes de renderizar
        recomputePrioritySlots();
        const assignedDemands = getDemands()
            .filter(demand => demand.responsible === currentUser)
            .sort((a, b) => (b.analyticsScore ?? -1) - (a.analyticsScore ?? -1) || a.id - b.id);
        const categoryRanking = buildCategoryRankingMap();
        
        // Botão de export para focais (que são admins)
        const permissions = await getUserPermissions(currentUser);
        const exportButton = permissions.canExport ? 
            '<button class="btn btn-success" onclick="exportToExcel()"><i class="fas fa-file-excel me-1"></i>Exportar Excel</button>' : '';
        
        appContent.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-tasks me-2"></i>Demandas Atribuídas</h2>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary" data-action="goto-my-requests">
                        <i class="fas fa-list me-1"></i>Minhas Demandas
                    </button>
                    ${exportButton}
                    <button class="btn btn-primary" data-action="goto-new-request">
                        <i class="fas fa-plus me-1"></i>Nova Demanda
                    </button>
                </div>
            </div>
            
            ${assignedDemands.length === 0 ? 
                `<div class="text-center py-5">
                    <i class="fas fa-clipboard-list fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted">Nenhuma demanda atribuída</h4>
                    <p class="text-muted">Você não possui demandas atribuídas no momento.</p>
                </div>` :
                `<div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Ranking</th>
                                <th>ID Sistema</th>
                                <th>ID Real</th>
                                <th>Solicitante</th>
                                <th>Grupo</th>
                                <th>Cenário</th>
                                <th>Submotivo</th>
                                <th>Status</th>
                                <th>Prioridade</th>
                                <th>Data Abertura</th>
                                <th>Aging</th>
                                <th>Prazo</th>
                                <th>Status Prazo</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${assignedDemands.map(demand => {
                                const deadlineStatus = calculateDeadlineStatus(demand.createdAt, demand.deadline, demand.status);
                                const rank = categoryRanking.get(demand.id) || '-';
                                const rankBadge = createRankBadge(rank);
                                return `
                                    <tr>
                                        <td>${rankBadge}</td>
                                        <td><strong>#${demand.id}</strong></td>
                                        <td><span class="badge bg-info text-dark">${demand.real_demand_id || 'N/A'}</span></td>
                                        <td><small>${getUserName(demand.requester)}</small></td>
                                        <td><small>${demand.group_name || demand.group || 'N/A'}</small></td>
                                        <td><small>${demand.scenario}</small></td>
                                        <td><small class="text-primary">${demand.submotivo || 'N/A'}</small></td>
                                        <td><span class="badge status-badge status-${(demand.status || 'novo').toLowerCase().replace(' ', '-')}">${demand.status || 'Novo'}</span></td>
                                        <td>
                                            <span class="badge priority-${getPriorityCssClass(demand.priority)}">${getPriorityString(demand.priority)}</span>
                                            <small class="text-primary ms-1">(${demand.analyticsScore || 0}pts)</small>
                                        </td>
                                        <td><small>${formatDate(demand.open_date || demand.created_at || demand.createdAt)}</small></td>
                                        <td><small>${calculateAging(demand.open_date || demand.created_at || demand.createdAt)}</small></td>
                                        <td><small>${formatDeadline(demand.deadline)}</small></td>
                                        <td><span class="badge ${deadlineStatus.class}">${deadlineStatus.text}</span></td>
                                        <td>
                                            <button class="btn btn-sm btn-outline-primary" data-action="view-timeline" data-id="${demand.id}">
                                                <i class="fas fa-eye me-1"></i>Ver
                                            </button>
                                        </td>
                                    </tr>
                                `;
                            }).join('')}
                        </tbody>
                    </table>
                </div>`
            }
        `;
    };

    // Renderizar painel admin
    const renderAdminPanel = async () => {
        // Recalcula antes de exibir visão administrativa
        recomputePrioritySlots();
        
        // Botão de export para admins
        const permissions = await getUserPermissions(currentUser);
        const exportButton = permissions.canExport ? 
            '<button class="btn btn-success" onclick="exportToExcel()"><i class="fas fa-file-excel me-1"></i>Exportar Excel</button>' : '';
        
        appContent.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-cogs me-2"></i>Gerenciar Demandas</h2>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary" data-action="my-requests">
                        <i class="fas fa-list me-1"></i>Minhas Demandas
                    </button>
                    ${exportButton}
                    <button class="btn btn-primary" data-action="new-request">
                        <i class="fas fa-plus me-1"></i>Nova Demanda
                    </button>
                </div>
            </div>
            
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Ranking</th>
                            <th>ID Sistema</th>
                            <th>ID Real</th>
                            <th>Solicitante</th>
                            <th>Grupo</th>
                            <th>Cenário</th>
                            <th>Submotivo</th>
                            <th>Status</th>
                            <th>Prioridade</th>
                            <th>Data Abertura</th>
                            <th>Aging</th>
                            <th>Responsável</th>
                            <th>Prazo</th>
                            <th>Status Prazo</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                            ${getDemands()
                            .slice()
                            .sort((a, b) => (b.analyticsScore ?? -1) - (a.analyticsScore ?? -1) || a.id - b.id)
                            .map(demand => {
                            const deadlineStatus = calculateDeadlineStatus(demand.createdAt, demand.deadline, demand.status);
                            // ✅ USAR RANKING POR CATEGORIA
                            const categoryRanking = buildCategoryRankingMap();
                            const rank = categoryRanking.get(demand.id) || '-';
                            const rankBadge = createRankBadge(rank);
                            return `
                                <tr>
                                    <td>${rankBadge}</td>
                                    <td><strong>#${demand.id}</strong></td>
                                    <td><span class="badge bg-info text-dark">${demand.real_demand_id || 'N/A'}</span></td>
                                    <td><small>${getUserName(demand.requester)}</small></td>
                                    <td><small>${demand.group_name || demand.group || 'N/A'}</small></td>
                                    <td><small>${demand.scenario}</small></td>
                                    <td><small class="text-primary">${demand.submotivo || 'N/A'}</small></td>
                                    <td><span class="badge status-badge status-${(demand.status || 'novo').toLowerCase().replace(' ', '-')}">${demand.status || 'Novo'}</span></td>
                                    <td>
                                        <span class="badge priority-${getPriorityCssClass(demand.priority)}">${getPriorityString(demand.priority)}</span>
                                        <small class="text-primary ms-1">(${demand.analyticsScore || 0}pts)</small>
                                    </td>
                                    <td><small>${formatDate(demand.open_date || demand.created_at || demand.createdAt)}</small></td>
                                    <td><small>${calculateAging(demand.open_date || demand.created_at || demand.createdAt)}</small></td>
                                    <td><small>${demand.responsible_name || getUserName(demand.responsible) || '-'}</small></td>
                                    <td><small>${formatDeadline(demand.deadline)}</small></td>
                                    <td><span class="badge ${deadlineStatus.class}">${deadlineStatus.text}</span></td>
                                    <td>
                                        <div class="btn-group" role="group">
                                            <button class="btn btn-sm btn-outline-primary" data-action="view-timeline" data-id="${demand.id}">
                                                <i class="fas fa-eye me-1"></i>Ver
                                            </button>
                                            <button class="btn btn-sm btn-outline-danger" data-action="open-redistribute" data-id="${demand.id}">
                                                <i class="fas fa-exchange-alt me-1"></i>Redistribuir
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            `;
                        }).join('')}
                    </tbody>
                </table>
            </div>
        `;
    };

    // ✅ FUNÇÃO PARA OBTER CATEGORIA E SIGLA DO CENÁRIO
    const getCategoriaFromScenario = (scenario) => {
        const categorias = {
            // Operacional
            'Apoio operacional': { categoria: 'Operacional', sigla: 'Op' },
            'Automações': { categoria: 'Operacional', sigla: 'Op' },
            'Controles operacionais': { categoria: 'Operacional', sigla: 'Op' },
            'Quartis': { categoria: 'Operacional', sigla: 'Op' },
            'Rechamada': { categoria: 'Operacional', sigla: 'Op' },
            'Reincidência': { categoria: 'Operacional', sigla: 'Op' },
            'Reports recorrentes': { categoria: 'Operacional', sigla: 'Op' },
            'Retratação': { categoria: 'Operacional', sigla: 'Op' },
            'WDE': { categoria: 'Operacional', sigla: 'Op' },
            'Whisper': { categoria: 'Operacional', sigla: 'Op' },
            
            // Qualidade
            'NPS': { categoria: 'Qualidade', sigla: 'Ql' },
            'TDNA': { categoria: 'Qualidade', sigla: 'Ql' },
            'TOP Care': { categoria: 'Qualidade', sigla: 'Ql' },
            
            // Analytics
            'Análises de eficiência': { categoria: 'Analytics', sigla: 'An' },
            'Diagnóstico Qualitativo': { categoria: 'Analytics', sigla: 'An' },
            'Diagnóstico Quantitativo': { categoria: 'Analytics', sigla: 'An' },
            'Oportunidades em relatatório de Analytics': { categoria: 'Analytics', sigla: 'An' },
            
            // Processos
            'Processos Fixa': { categoria: 'Processos', sigla: 'Pr' },
            'Processos Móvel': { categoria: 'Processos', sigla: 'Pr' },
            
            // Projetos
            'Projetos': { categoria: 'Projetos', sigla: 'Pj' }
        };
        
        return categorias[scenario] || { categoria: 'Outros', sigla: 'Ot' };
    };

    // ✅ FUNÇÃO PARA CALCULAR RANKING POR CATEGORIA
    const buildCategoryRankingMap = () => {
        const demandsByCategory = new Map();
        
        // Agrupar demandas por categoria
        getDemands().forEach(demand => {
            const categoryInfo = getCategoriaFromScenario(demand.scenario);
            const categoria = demand.categoria || categoryInfo.categoria;
            
            if (!demandsByCategory.has(categoria)) {
                demandsByCategory.set(categoria, []);
            }
            
            // Só incluir demandas com pontuação válida
            if (demand.analyticsScore !== null && demand.analyticsScore !== undefined && demand.analyticsScore >= 0) {
                demandsByCategory.get(categoria).push(demand);
            }
        });
        
        // Calcular ranking dentro de cada categoria
        const rankingMap = new Map();
        
        demandsByCategory.forEach((demands, categoria) => {
            // Ordenar por pontuação (maior primeiro)
            demands.sort((a, b) => (b.analyticsScore || 0) - (a.analyticsScore || 0));
            
            // Atribuir rankings com sigla
            demands.forEach((demand, index) => {
                const categoryInfo = getCategoriaFromScenario(demand.scenario);
                const sigla = categoryInfo.sigla;
                const position = index + 1;
                rankingMap.set(demand.id, `${sigla}${position}`);
            });
        });
        
        return rankingMap;
    };

    // Dashboard - Analytics Demandas Moderno
    const renderAnalyticsRanking = () => {
        const allDemands = getDemands();
        const totalDemands = allDemands.length;
        const openDemands = allDemands.filter(d => !isStatusFinalizado(d.status)).length;
        const closedDemands = allDemands.filter(d => isStatusConcluido(d.status)).length;
        const completionRate = Math.round((closedDemands / (totalDemands || 1)) * 100);

        // ✅ CENÁRIOS - Estatísticas por Cenário (em vez de Staff)
        const scenarioStats = {};
        allDemands.forEach(demand => {
            const scenario = demand.scenario || 'Não informado';
            if (!scenarioStats[scenario]) {
                scenarioStats[scenario] = { aberturas: 0 };
            }
            scenarioStats[scenario].aberturas += 1;
        });

        // ✅ GRÁFICO DE BARRAS - Por Cenário (Top 8)
        const topScenarios = Object.entries(scenarioStats)
            .sort(([, a], [, b]) => b.aberturas - a.aberturas)
            .slice(0, 8);

        const scenarioChartBars = topScenarios.map(([scenario, stats], index) => {
            const percentage = (stats.aberturas / totalDemands) * 100;
            const barHeight = Math.max(percentage * 4, 25); // Altura ajustada
            const scenarioName = scenario.length > 12 ? scenario.substring(0, 12) + '...' : scenario;
            const categoryInfo = getCategoriaFromScenario(scenario);
            
            return `
                <div class="d-flex flex-column align-items-center mx-1" style="min-width: 90px;" 
                     title="📊 ${scenario}&#10;📈 ${stats.aberturas} demandas (${percentage.toFixed(1)}%)&#10;🏷️ Categoria: ${categoryInfo.categoria} (${categoryInfo.sigla})&#10;📋 Clique para mais detalhes">
                    <div class="d-flex align-items-end justify-content-center mb-2" style="height: 140px;">
                        <div class="rounded-top d-flex align-items-end justify-content-center text-white fw-bold scenario-bar" 
                             style="width: 40px; height: ${barHeight}px; font-size: 11px; background: linear-gradient(180deg, #6f42c1, #8b5cf6); box-shadow: 0 2px 8px rgba(111, 66, 193, 0.3); cursor: pointer;"
                             data-scenario="${scenario}" data-count="${stats.aberturas}" data-category="${categoryInfo.categoria}" data-sigla="${categoryInfo.sigla}">
                            ${stats.aberturas}
                        </div>
                    </div>
                    <small class="text-center text-muted" style="font-size: 10px; line-height: 1.2; max-width: 80px;">
                        ${scenarioName}
                    </small>
                </div>
            `;
        }).join('');

        // ✅ SUBMOTIVOS - Gráfico de barras horizontal
        const topSubmotivos = Object.entries(allDemands.reduce((acc, demand) => {
            const submotivo = demand.submotivo || 'Não informado';
            acc[submotivo] = (acc[submotivo] || 0) + 1;
            return acc;
        }, {}))
        .sort(([, a], [, b]) => b - a)
        .slice(0, 6);

        const submotivoChartBars = topSubmotivos.map(([submotivo, count]) => {
            const maxCount = Math.max(...topSubmotivos.map(([, c]) => c));
            const percentage = (count / maxCount) * 100;
            
            return `
                <div class="mb-3">
                    <div class="d-flex justify-content-between align-items-center mb-1">
                        <span class="text-primary fw-bold" style="font-size: 12px;">${submotivo.length > 20 ? submotivo.substring(0, 20) + '...' : submotivo}</span>
                        <span class="badge bg-info">${count}</span>
                    </div>
                    <div class="progress" style="height: 8px;">
                        <div class="progress-bar bg-gradient" role="progressbar" 
                             style="width: ${percentage}%; background: linear-gradient(90deg, #6f42c1, #8b5cf6);">
                        </div>
                    </div>
                </div>
            `;
        }).join('');

        // ✅ STATUS - Gráfico de pizza visual
        const statusData = Object.entries(allDemands.reduce((acc, demand) => {
            const status = demand.status || 'Sem status';
            acc[status] = (acc[status] || 0) + 1;
            return acc;
        }, {})).sort(([, a], [, b]) => b - a);

        const statusColors = {
            'Aberta': '#3b82f6',
            'Em análise': '#8b5cf6', 
            'Em andamento': '#eab308',
            'Aguardando aprovação': '#f97316',
            'Aguardando retorno ( demandante)': '#ef4444',
            'Concluída': '#10b981',
            'Cancelada': '#6b7280'
        };

        const statusPieSegments = statusData.map(([status, count], index) => {
            const percentage = (count / totalDemands) * 100;
            const color = statusColors[status] || '#6b7280';
            
            return `
                <div class="d-flex justify-content-between align-items-center mb-2 p-2 rounded" style="background: ${color}15;">
                    <div class="d-flex align-items-center">
                        <div class="rounded-circle me-2" style="width: 12px; height: 12px; background: ${color};"></div>
                        <span class="fw-bold" style="font-size: 12px;">${status}</span>
                    </div>
                    <div class="text-end">
                        <div class="fw-bold">${count}</div>
                        <small class="text-muted">${percentage.toFixed(1)}%</small>
                    </div>
                </div>
            `;
        }).join('');

        // ✅ DEMANDAS RECENTES com design moderno
        const recentDemands = allDemands
            .sort((a, b) => new Date(b.created_at || b.open_date) - new Date(a.created_at || a.open_date))
            .slice(0, 6);

        const recentCards = recentDemands.map(demand => `
            <div class="card mb-2 border-0 shadow-sm hover-lift" style="transition: all 0.3s ease;">
                <div class="card-body p-3">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge bg-secondary">#${demand.id}</span>
                            <span class="badge bg-info text-dark">${demand.real_demand_id || 'N/A'}</span>
                        </div>
                        <small class="text-muted">${formatDate(demand.open_date || demand.created_at)}</small>
                    </div>
                    <div class="mb-1">
                        <small class="text-dark fw-bold">${demand.scenario}</small>
                    </div>
                    <div class="d-flex justify-content-between align-items-center">
                        <small class="text-primary">${demand.submotivo || 'N/A'}</small>
                        <small class="text-muted">${getUserName(demand.requester)}</small>
                    </div>
                </div>
            </div>
        `).join('');

        appContent.innerHTML = `
            <!-- Header moderno -->
            <div class="d-flex align-items-center justify-content-between mb-4">
                <div class="d-flex align-items-center gap-3">
                    <div class="p-2 rounded-circle" style="background: linear-gradient(135deg, #6f42c1, #8b5cf6);">
                        <i class="fas fa-chart-line text-white"></i>
                    </div>
                    <h2 class="mb-0 fw-bold" style="background: linear-gradient(135deg, #6f42c1, #8b5cf6); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">
                        Dashboard
                    </h2>
                </div>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary btn-sm">
                        <i class="fas fa-download me-1"></i>Exportar
                    </button>
                    <button class="btn btn-primary btn-sm">
                        <i class="fas fa-refresh me-1"></i>Atualizar
                    </button>
                </div>
            </div>

            <!-- Métricas Principais - Design Moderno -->
            <div class="row mb-4">
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm hover-lift" style="background: linear-gradient(135deg, #6f42c1, #8b5cf6); transition: all 0.3s ease;">
                        <div class="card-body text-white p-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0 fw-bold">${totalDemands}</h3>
                                    <p class="mb-0 opacity-90"><i class="fas fa-list me-1"></i>Total Demandas</p>
                                </div>
                                <i class="fas fa-chart-bar fa-2x opacity-70"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm hover-lift" style="background: linear-gradient(135deg, #eab308, #f59e0b); transition: all 0.3s ease;">
                        <div class="card-body text-white p-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0 fw-bold">${openDemands}</h3>
                                    <p class="mb-0 opacity-90"><i class="fas fa-clock me-1"></i>Abertas</p>
                                </div>
                                <i class="fas fa-hourglass-half fa-2x opacity-70"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm hover-lift" style="background: linear-gradient(135deg, #10b981, #059669); transition: all 0.3s ease;">
                        <div class="card-body text-white p-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0 fw-bold">${closedDemands}</h3>
                                    <p class="mb-0 opacity-90"><i class="fas fa-check-circle me-1"></i>Concluídas</p>
                                </div>
                                <i class="fas fa-check-double fa-2x opacity-70"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card border-0 shadow-sm hover-lift" style="background: linear-gradient(135deg, #06b6d4, #0891b2); transition: all 0.3s ease;">
                        <div class="card-body text-white p-4">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h3 class="mb-0 fw-bold">${completionRate}%</h3>
                                    <p class="mb-0 opacity-90"><i class="fas fa-percentage me-1"></i>Taxa Conclusão</p>
                                </div>
                                <i class="fas fa-chart-pie fa-2x opacity-70"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Analytics Grid Moderno -->
            <div class="row mb-4">
                <!-- Cenários Chart (corrigido layout) -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white border-bottom">
                            <h6 class="mb-0 d-flex align-items-center">
                                <i class="fas fa-chart-bar me-2 text-primary"></i>
                                <span class="fw-bold">Por Cenário</span>
                            </h6>
                        </div>
                        <div class="card-body p-3">
                            <div class="d-flex justify-content-around align-items-end overflow-auto" 
                                 style="min-height: 180px; max-height: 200px; background: linear-gradient(180deg, #f8f9fa, #ffffff); padding: 15px;">
                                ${scenarioChartBars}
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Submotivos Chart -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white border-bottom">
                            <h6 class="mb-0 d-flex align-items-center">
                                <i class="fas fa-tags me-2 text-primary"></i>
                                <span class="fw-bold">Top Submotivos</span>
                            </h6>
                        </div>
                        <div class="card-body">
                            <div style="max-height: 200px; overflow-y: auto;" class="scrollbar-custom">
                                ${submotivoChartBars}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Segunda Linha - Status e Cenários -->
            <div class="row mb-4">
                <!-- Status Distribution -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white border-bottom">
                            <h6 class="mb-0 d-flex align-items-center">
                                <i class="fas fa-chart-donut me-2 text-primary"></i>
                                <span class="fw-bold">Distribuição por Status</span>
                            </h6>
                        </div>
                        <div class="card-body">
                            <div style="max-height: 250px; overflow-y: auto;" class="scrollbar-custom">
                                ${statusPieSegments}
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Demandas Recentes - Cards Modernos -->
                <div class="col-md-6">
                    <div class="card border-0 shadow-sm h-100">
                        <div class="card-header bg-white border-bottom">
                            <h6 class="mb-0 d-flex align-items-center">
                                <i class="fas fa-clock me-2 text-primary"></i>
                                <span class="fw-bold">Demandas Recentes</span>
                            </h6>
                        </div>
                        <div class="card-body">
                            <div style="max-height: 250px; overflow-y: auto;" class="scrollbar-custom">
                                ${recentCards}
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Gráfico de Aging por Cenário -->
            <div class="row">
                <div class="col-12">
                    <div class="card border-0 shadow-sm">
                        <div class="card-header bg-white border-bottom">
                            <h6 class="mb-0 d-flex align-items-center">
                                <i class="fas fa-chart-line me-2 text-primary"></i>
                                <span class="fw-bold">Aging por Cenário (Demandas Abertas)</span>
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                ${topScenarios.map(([scenario, stats]) => {
                                    // Calcular aging médio para este cenário
                                    const scenarioDemands = allDemands.filter(d => d.scenario === scenario && !isStatusFinalizado(d.status));
                                    let totalAging = 0;
                                    let agingCount = 0;
                                    
                                    scenarioDemands.forEach(demand => {
                                        const created = new Date(demand.open_date || demand.created_at);
                                        const now = new Date();
                                        const diffTime = Math.abs(now - created);
                                        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
                                        totalAging += diffDays;
                                        agingCount++;
                                    });
                                    
                                    const avgAging = agingCount > 0 ? Math.round(totalAging / agingCount) : 0;
                                    const maxAging = Math.max(...topScenarios.map(([s]) => {
                                        const sDemands = allDemands.filter(d => d.scenario === s && !isStatusFinalizado(d.status));
                                        let sTotal = 0, sCount = 0;
                                        sDemands.forEach(d => {
                                            const created = new Date(d.open_date || d.created_at);
                                            const now = new Date();
                                            const diffDays = Math.ceil(Math.abs(now - created) / (1000 * 60 * 60 * 24));
                                            sTotal += diffDays;
                                            sCount++;
                                        });
                                        return sCount > 0 ? Math.round(sTotal / sCount) : 0;
                                    }));
                                    
                                    const lineHeight = maxAging > 0 ? (avgAging / maxAging) * 100 : 0;
                                    const lineColor = avgAging > 30 ? '#ef4444' : avgAging > 15 ? '#eab308' : '#10b981';
                                    
                                                                         return `
                                         <div class="col-md-3 mb-4">
                                             <div class="card h-100 border-0 aging-card" style="background: linear-gradient(135deg, #ffffff, #f8f9fa); cursor: pointer;" 
                                                  title="📊 ${scenario}&#10;📈 ${stats.aberturas} demandas abertas&#10;⏱️ Aging médio: ${avgAging} dias&#10;🏷️ Categoria: ${getCategoriaFromScenario(scenario).categoria}&#10;📋 Clique para detalhes"
                                                  data-scenario="${scenario}" data-aging="${avgAging}" data-count="${stats.aberturas}" data-category="${getCategoriaFromScenario(scenario).categoria}">
                                                 <div class="card-body text-center">
                                                     <h6 class="text-primary mb-3">${scenario.length > 20 ? scenario.substring(0, 20) + '...' : scenario}</h6>
                                                     <div class="mb-3">
                                                         <div class="d-flex justify-content-center align-items-end" style="height: 80px;">
                                                             <div class="rounded-top aging-bar" style="width: 30px; height: ${Math.max(lineHeight, 10)}%; background: ${lineColor}; transition: all 0.3s ease;"></div>
                                                         </div>
                                                     </div>
                                                     <div class="text-center">
                                                         <div class="h5 mb-1" style="color: ${lineColor};">${avgAging}</div>
                                                         <small class="text-muted">dias (média)</small>
                                                     </div>
                                                     <div class="mt-2">
                                                         <small class="badge" style="background: ${lineColor}20; color: ${lineColor};">${stats.aberturas} demandas</small>
                                                     </div>
                                                 </div>
                                             </div>
                                         </div>
                                     `;
                                }).join('')}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // ✅ ADICIONAR EVENT LISTENERS PARA CLIQUES NOS GRÁFICOS
        setTimeout(() => {
            // Cliques nas barras do gráfico de cenários
            document.querySelectorAll('.scenario-bar').forEach(bar => {
                bar.addEventListener('click', (e) => {
                    const scenario = e.target.getAttribute('data-scenario');
                    const count = e.target.getAttribute('data-count');
                    const category = e.target.getAttribute('data-category');
                    const sigla = e.target.getAttribute('data-sigla');
                    
                    const message = `📊 Detalhes do Cenário:
                    
🏷️ Nome: ${scenario}
📈 Total de Demandas: ${count}
📂 Categoria: ${category}
🔤 Sigla do Ranking: ${sigla}
                    
💡 Demandas desta categoria são rankeadas como ${sigla}1, ${sigla}2, ${sigla}3...`;
                    
                    showToast(message, 'info');
                });
            });
            
            // Hover effect nas barras
            document.querySelectorAll('.scenario-bar').forEach(bar => {
                bar.addEventListener('mouseenter', (e) => {
                    e.target.style.transform = 'scale(1.05)';
                    e.target.style.boxShadow = '0 4px 15px rgba(111, 66, 193, 0.5)';
                });
                
                bar.addEventListener('mouseleave', (e) => {
                    e.target.style.transform = 'scale(1)';
                    e.target.style.boxShadow = '0 2px 8px rgba(111, 66, 193, 0.3)';
                });
            });
            
            // ✅ CLIQUES NO GRÁFICO DE AGING
            document.querySelectorAll('.aging-card').forEach(card => {
                card.addEventListener('click', (e) => {
                    const scenario = e.currentTarget.getAttribute('data-scenario');
                    const aging = e.currentTarget.getAttribute('data-aging');
                    const count = e.currentTarget.getAttribute('data-count');
                    const category = e.currentTarget.getAttribute('data-category');
                    
                    const urgencyLevel = aging > 30 ? '🔴 Crítico' : aging > 15 ? '🟡 Atenção' : '🟢 Normal';
                    
                    const message = `📊 Aging - ${scenario}:
                    
⏱️ Aging Médio: ${aging} dias
📈 Demandas Abertas: ${count}
🏷️ Categoria: ${category}
📊 Nível de Urgência: ${urgencyLevel}
                    
💡 Aging = tempo médio desde a abertura das demandas ainda não finalizadas`;
                    
                    showToast(message, aging > 30 ? 'error' : aging > 15 ? 'warning' : 'success');
                });
                
                // Hover effect nos cards de aging
                card.addEventListener('mouseenter', (e) => {
                    e.currentTarget.style.transform = 'translateY(-2px)';
                    e.currentTarget.style.boxShadow = '0 8px 25px rgba(111, 66, 193, 0.15)';
                });
                
                card.addEventListener('mouseleave', (e) => {
                    e.currentTarget.style.transform = 'translateY(0)';
                    e.currentTarget.style.boxShadow = 'none';
                });
            });
        }, 500);
    };

    // Renderizar demandas gerais (visualização para colaboradores)
    const renderGeneralDemands = async () => {
        try {
            const users = await getUsers();
            const user = users.find(u => u.username === currentUser) || { role: 'colaborador' };
            const all = await getDemands();
            
            // Garante prioridades consistentes ao entrar nesta visão
            recomputePrioritySlots();
            const uniq = arr => Array.from(new Set(arr.filter(Boolean)));
            
            // ✅ RANKING POR CATEGORIA (Op1, Ql2, An3, etc.)
            const rankById = buildCategoryRankingMap();
            const groups = uniq(all.map(d => d.group));
            const scenarios = uniq(all.map(d => d.scenario));
            const statuses = uniq(all.map(d => d.status));
            const priorities = uniq(all.map(d => d.priority));
            const responsibles = uniq(all.map(d => d.responsible ? getUserName(d.responsible) : '-'));

        appContent.innerHTML = `
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2><i class="fas fa-chart-bar me-2"></i>Demandas Gerais</h2>
                <div class="d-flex gap-2">
                    <button class="btn btn-outline-primary" data-action="my-requests">
                        <i class="fas fa-list me-1"></i>Minhas Demandas
                    </button>
                    <button class="btn btn-primary" data-action="new-request">
                        <i class="fas fa-plus me-1"></i>Nova Demanda
                    </button>
                </div>
            </div>
            
            <div class="alert alert-info border">
                <i class="fas fa-info-circle me-2"></i>
                <strong>Visualização Geral:</strong> Esta tela mostra todas as demandas abertas no time para você entender o volume de trabalho.
                ${user.role === 'colaborador' ? 'Você pode apenas visualizar as informações.' : ''}
            </div>

            <div class="card mb-3"><div class="card-body">
              <div class="row g-2 align-items-end">
                <div class="col-md-2">
                  <label class="form-label">Solicitante</label>
                  <input type="text" class="form-control" id="flt-requester" placeholder="Nome ou matrícula">
                </div>
                <div class="col-md-2">
                  <label class="form-label">ID Real</label>
                  <input type="text" class="form-control" id="flt-real-id" placeholder="Ex: DEM-2024-001">
                </div>
                <div class="col-md-2">
                  <label class="form-label">Grupo</label>
                  <select class="form-select" id="flt-group">
                    <option value="">Todos</option>
                    ${groups.map(g => `<option value="${g}">${g}</option>`).join('')}
                  </select>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Cenário</label>
                  <select class="form-select" id="flt-scenario">
                    <option value="">Todos</option>
                    ${scenarios.map(s => `<option value="${s}">${s}</option>`).join('')}
                  </select>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Submotivo</label>
                  <div class="autocomplete-container">
                    <input type="text" class="form-control" id="flt-submotivo" placeholder="Digite o submotivo..." autocomplete="off">
                    <div class="autocomplete-suggestions" id="submotivo-suggestions"></div>
                  </div>
                </div>
              </div>
              <div class="row g-2 align-items-end mt-2">
                <div class="col-md-2">
                  <label class="form-label">Status</label>
                  <select class="form-select" id="flt-status">
                    <option value="">Todos</option>
                    ${statuses.map(s => `<option value="${s}">${s}</option>`).join('')}
                  </select>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Prioridade</label>
                  <select class="form-select" id="flt-priority">
                    <option value="">Todas</option>
                    ${priorities.map(p => `<option value="${p}">${p}</option>`).join('')}
                  </select>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Responsável</label>
                  <select class="form-select" id="flt-responsible">
                    <option value="">Todos</option>
                    <option value="-">-</option>
                    ${responsibles.map(r => `<option value="${r}">${r}</option>`).join('')}
                  </select>
                </div>
                <div class="col-md-2">
                  <label class="form-label">Status Prazo</label>
                  <select class="form-select" id="flt-deadline">
                    <option value="">Todos</option>
                    <option value="dentro">Dentro do prazo</option>
                    <option value="fora">Fora do prazo</option>
                    <option value="sem">Sem prazo</option>
                  </select>
                </div>
                <div class="col-md-2">
                  <button class="btn btn-outline-secondary w-100" id="btn-clear-filters"><i class="fas fa-eraser me-1"></i>Limpar</button>
                </div>
              </div>
            </div></div>
            
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Ranking</th>
                            <th>ID Sistema</th>
                            <th>ID Real</th>
                            <th>Solicitante</th>
                            <th>Grupo</th>
                            <th>Cenário</th>
                            <th>Submotivo</th>
                            <th>Status</th>
                            <th>Prioridade</th>
                            <th>Data Abertura</th>
                            <th>Aging</th>
                            <th>Responsável</th>
                            <th>Prazo</th>
                            <th>Status Prazo</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody id="tb-general-body"></tbody>
                </table>
            </div>
        `;

        const bodyEl = document.getElementById('tb-general-body');
        const getDeadlineKey = (d) => {
            const s = calculateDeadlineStatus(d.createdAt, d.deadline, d.status).status;
            return s === 'dentro' ? 'dentro' : s === 'fora' ? 'fora' : 'sem';
        };
        const applyFilters = () => {
            const fRequester = document.getElementById('flt-requester').value.trim().toLowerCase();
            const fRealId = document.getElementById('flt-real-id').value.trim().toLowerCase();
            const fSubmotivo = document.getElementById('flt-submotivo').value.trim().toLowerCase();
            const fGroup = document.getElementById('flt-group').value;
            const fScenario = document.getElementById('flt-scenario').value;
            const fStatus = document.getElementById('flt-status').value;
            const fPriority = document.getElementById('flt-priority').value;
            const fResp = document.getElementById('flt-responsible').value;
            const fDeadline = document.getElementById('flt-deadline').value;

            const filtered = all.filter(d => {
                if (fRequester) {
                    const reqName = getUserName(d.requester).toLowerCase();
                    if (!(reqName.includes(fRequester) || (d.requester||'').toLowerCase().includes(fRequester))) return false;
                }
                // ✅ NOVO FILTRO: ID Real da Demanda
                if (fRealId) {
                    const realId = (d.real_demand_id || '').toLowerCase();
                    if (!realId.includes(fRealId)) return false;
                }
                // ✅ NOVO FILTRO: Submotivo
                if (fSubmotivo) {
                    const submotivo = (d.submotivo || '').toLowerCase();
                    if (!submotivo.includes(fSubmotivo)) return false;
                }
                if (fGroup && d.group !== fGroup) return false;
                if (fScenario && d.scenario !== fScenario) return false;
                if (fStatus && d.status !== fStatus) return false;
                if (fPriority && (d.priority||'') !== fPriority) return false;
                if (fResp) {
                    const name = d.responsible ? getUserName(d.responsible) : '-';
                    if (name !== fResp) return false;
                }
                if (fDeadline && getDeadlineKey(d) !== fDeadline) return false;
                return true;
            })
            // Ordena por ranking geral dentro do responsável, depois por score desc globalmente
            .sort((a, b) => {
                // Dentro de cada responsável, ordena por ranking (posição menor primeiro)
                const ra = rankById.get(a.id) || 999999;
                const rb = rankById.get(b.id) || 999999;
                if (a.responsible && b.responsible && a.responsible === b.responsible) {
                    if (ra !== rb) return ra - rb; // menor posição primeiro
                }
                // Fora do mesmo responsável, ordena por score desc (analytics primeiro)
                const sa = (a.analyticsScore ?? -1);
                const sb = (b.analyticsScore ?? -1);
                if (sa !== sb) return sb - sa;
                return a.id - b.id;
            });

            bodyEl.innerHTML = filtered.map(demand => {
                const deadlineStatus = calculateDeadlineStatus(demand.createdAt, demand.deadline, demand.status);
                const rank = rankById.get(demand.id) || '-';
                const rankBadge = createRankBadge(rank);
                
                // Mostrar pontuação de todas as demandas (sempre exibir pontuação)
                const priorityDisplay = demand.priority || '-';
                const score = demand.analyticsScore || 0;
                const scoreDisplay = `<small class="text-primary ms-2">(${score}pts)</small>`;
                
                return `
                    <tr>
                        <td>${rankBadge}</td>
                        <td><strong>#${demand.id}</strong></td>
                        <td><span class="badge bg-info text-dark">${demand.real_demand_id || 'N/A'}</span></td>
                        <td><small>${getUserName(demand.requester)}</small></td>
                        <td><small>${demand.group_name || demand.group || 'N/A'}</small></td>
                        <td><small>${demand.scenario}</small></td>
                        <td><small class="text-primary">${demand.submotivo || 'N/A'}</small></td>
                        <td><span class="badge status-badge status-${(demand.status || 'novo').toLowerCase().replace(/\s+/g,'-')}">${demand.status || 'Novo'}</span></td>
                        <td>
                            <span class="badge priority-${getPriorityCssClass(demand.priority)}">${priorityDisplay}</span>
                            <small class="text-primary ms-1">(${score}pts)</small>
                        </td>
                        <td><small>${formatDate(demand.open_date || demand.created_at || demand.createdAt)}</small></td>
                        <td><small>${calculateAging(demand.open_date || demand.created_at || demand.createdAt)}</small></td>
                        <td><small>${demand.responsible_name || getUserName(demand.responsible) || '-'}</small></td>
                        <td><small>${formatDeadline(demand.deadline)}</small></td>
                        <td><span class="badge ${deadlineStatus.class}">${deadlineStatus.text}</span></td>
                        <td>
                            <div class="btn-group" role="group" aria-label="Ações da demanda">
                                <button class="btn btn-sm btn-outline-primary" data-action="view-timeline" data-id="${demand.id}" title="Ver timeline da demanda">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-warning" data-action="edit-demand-id" data-id="${demand.id}" title="🔶 Editar ID Real">
                                    <i class="fas fa-hashtag"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-info" data-action="edit-demand-date" data-id="${demand.id}" title="🔷 Editar Data de Abertura">
                                    <i class="fas fa-calendar"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                `;
            }).join('');
        };

        // ✅ FUNÇÃO DE AUTOCOMPLETE PARA SUBMOTIVO
        const setupSubmotivoAutocomplete = () => {
            const input = document.getElementById('flt-submotivo');
            const suggestionsContainer = document.getElementById('submotivo-suggestions');
            
            if (!input || !suggestionsContainer) return;
            
            // Obter todos os submotivos únicos das demandas
            const getUniqueSubmotivos = () => {
                const submotivos = getDemands()
                    .map(d => d.submotivo)
                    .filter(s => s && s.trim() !== '')
                    .map(s => s.trim());
                
                // Remover duplicatas e ordenar
                return [...new Set(submotivos)].sort((a, b) => 
                    a.toLowerCase().localeCompare(b.toLowerCase(), 'pt-BR', { sensitivity: 'base' })
                );
            };
            
            // Filtrar sugestões baseado no texto digitado
            const filterSuggestions = (query) => {
                const allSubmotivos = getUniqueSubmotivos();
                if (!query.trim()) return allSubmotivos.slice(0, 10); // Mostrar apenas 10 primeiros se vazio
                
                const queryLower = query.toLowerCase();
                return allSubmotivos.filter(submotivo => 
                    submotivo.toLowerCase().includes(queryLower)
                ).slice(0, 8); // Máximo 8 sugestões
            };
            
            // Destacar texto correspondente
            const highlightMatch = (text, query) => {
                if (!query.trim()) return text;
                
                const regex = new RegExp(`(${query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi');
                return text.replace(regex, '<span class="highlight">$1</span>');
            };
            
            // Mostrar sugestões
            const showSuggestions = (suggestions, query = '') => {
                if (suggestions.length === 0) {
                    suggestionsContainer.innerHTML = '<div class="autocomplete-no-results">Nenhum submotivo encontrado</div>';
                } else {
                    suggestionsContainer.innerHTML = suggestions
                        .map(submotivo => `
                            <div class="autocomplete-item" data-value="${submotivo}">
                                ${highlightMatch(submotivo, query)}
                            </div>
                        `).join('');
                }
                
                suggestionsContainer.classList.add('show');
                suggestionsContainer.style.display = 'block';
            };
            
            // Esconder sugestões
            const hideSuggestions = () => {
                suggestionsContainer.classList.remove('show');
                setTimeout(() => {
                    suggestionsContainer.style.display = 'none';
                }, 200);
            };
            
            // Event listeners
            input.addEventListener('input', (e) => {
                const query = e.target.value;
                const suggestions = filterSuggestions(query);
                
                if (query.length >= 1) {
                    showSuggestions(suggestions, query);
                } else {
                    hideSuggestions();
                }
            });
            
            input.addEventListener('focus', (e) => {
                const query = e.target.value;
                const suggestions = filterSuggestions(query);
                showSuggestions(suggestions, query);
            });
            
            input.addEventListener('blur', () => {
                // Delay para permitir clique nas sugestões
                setTimeout(hideSuggestions, 200);
            });
            
            // Clique nas sugestões
            suggestionsContainer.addEventListener('click', (e) => {
                const item = e.target.closest('.autocomplete-item');
                if (item) {
                    const value = item.getAttribute('data-value');
                    input.value = value;
                    hideSuggestions();
                    applyFilters(); // Aplicar filtro automaticamente
                }
            });
            
            // Navegação por teclado
            let activeIndex = -1;
            input.addEventListener('keydown', (e) => {
                const items = suggestionsContainer.querySelectorAll('.autocomplete-item');
                
                if (e.key === 'ArrowDown') {
                    e.preventDefault();
                    activeIndex = Math.min(activeIndex + 1, items.length - 1);
                    updateActiveItem(items);
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    activeIndex = Math.max(activeIndex - 1, -1);
                    updateActiveItem(items);
                } else if (e.key === 'Enter') {
                    e.preventDefault();
                    if (activeIndex >= 0 && items[activeIndex]) {
                        const value = items[activeIndex].getAttribute('data-value');
                        input.value = value;
                        hideSuggestions();
                        applyFilters();
                    }
                } else if (e.key === 'Escape') {
                    hideSuggestions();
                    activeIndex = -1;
                }
            });
            
            // Atualizar item ativo na navegação por teclado
            const updateActiveItem = (items) => {
                items.forEach((item, index) => {
                    item.classList.toggle('active', index === activeIndex);
                });
            };
        };

        // Listeners de filtros (incluindo novos campos)
        ['flt-requester','flt-real-id','flt-group','flt-scenario','flt-status','flt-priority','flt-responsible','flt-deadline']
            .forEach(id => document.getElementById(id).addEventListener('input', applyFilters));
        document.getElementById('btn-clear-filters').addEventListener('click', () => {
            ['flt-requester','flt-real-id','flt-submotivo','flt-group','flt-scenario','flt-status','flt-priority','flt-responsible','flt-deadline']
                .forEach(id => { const el = document.getElementById(id); el.value = ''; });
            applyFilters();
        });

        // ✅ INICIALIZAR AUTOCOMPLETE DO SUBMOTIVO
        setupSubmotivoAutocomplete();
        
        applyFilters();
        } catch (error) {
            console.error('❌ Erro ao renderizar demandas gerais:', error);
            appContent.innerHTML = `
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Erro ao carregar demandas gerais. Tente recarregar a página.
                </div>
            `;
        }
    };

    // ===== EVENTOS =====

    const handleNewRequest = async (e) => {
        e.preventDefault();
        const form = document.getElementById('new-request-form');
        const group = document.getElementById('group').value;
        const scenario = document.getElementById('scenario').value;
        const observation = document.getElementById('observation').value;
        
        // ✅ CAPTURAR NOVOS CAMPOS
        const demandOpenDate = document.getElementById('demand-open-date').value;
        const realDemandId = document.getElementById('real-demand-id').value;
        const submotivo = document.getElementById('submotivo').value;

        // Validação completa (sempre exige a classificação)
        if (!form.checkValidity()) { form.reportValidity(); return; }

        try {
            // Atribuição automática de focal
            const autoFocal = findAutoFocalByScenarioOrObservation(scenario, observation);

            // Pontuação SEMPRE calculada (para todos os cenários)
            let analyticsScore = null;
            let analyticsPriority = null;
            
            // ✅ SEMPRE calcular score (usado para ranking A e G)
            analyticsScore = calculateInlineAnalyticsScore();
            analyticsPriority = getPriorityFromScore(analyticsScore);

            // ✅ LOG para debug
            console.log(`[FRONTEND-DEBUG] Criando demanda:`);
            console.log(`[FRONTEND-DEBUG] - Cenário: ${scenario}`);
            console.log(`[FRONTEND-DEBUG] - analyticsScore: ${analyticsScore} (${typeof analyticsScore})`);
            console.log(`[FRONTEND-DEBUG] - analyticsPriority: ${analyticsPriority} (${typeof analyticsPriority})`);
            console.log(`[FRONTEND-DEBUG] - priority (convertido): ${convertPriorityToApi(analyticsPriority || 'Média')}`);

            // Preparar dados para API
            const newDemand = {
                requester: currentUser,
                group_name: group,
                scenario: scenario,
                observation: observation,
                status: 'Aberta',
                priority: convertPriorityToApi(analyticsPriority || 'Média'), // ✅ SEMPRE usar "Média" como fallback
                responsible: autoFocal || null,
                deadline: null,
                analyticsScore: analyticsScore || 0, // ✅ SEMPRE um número
                analyticsPriority: analyticsPriority || 'Média', // ✅ SEMPRE uma string
                // ✅ NOVOS CAMPOS
                demand_open_date: demandOpenDate,
                real_demand_id: realDemandId,
                submotivo: submotivo,
                // Campos Analytics expandidos
                impacto_cliente_final: document.querySelector('[name="impacto_cliente_final"]')?.value || null,
                complexidade_tecnica: document.querySelector('[name="complexidade_tecnica"]')?.value || null,
                tdna: document.querySelector('[name="tdna"]')?.value || null,
                nps: document.querySelector('[name="nps"]')?.value || null,
                reincidencia: document.querySelector('[name="reincidencia"]')?.value || null,
                reclamada: document.querySelector('[name="reclamada"]')?.value || null,
                frequencia_automacao: document.querySelector('[name="frequencia_automacao"]')?.value || null,
                gestao_equipes_direta: document.querySelector('[name="gestao_equipes_direta"]')?.value || null,
                envolvimento_grupos: document.querySelector('[name="envolvimento_grupos"]')?.value || null,
                gerar_dentro_casa: document.querySelector('[name="gerar_dentro_casa"]')?.value || null
            };

            console.log('📋 Salvando nova demanda via API...', newDemand);
            
            // Salvar via API
            const result = await saveDemand(newDemand);
            
            if (result && result.success) {
                console.log('✅ Demanda salva com sucesso:', result.data);
                showToast(autoFocal ? `Demanda criada e atribuída automaticamente ao focal ${autoFocal}` : 'Demanda criada com sucesso!', 'success');
                
                // 🆕 FORÇAR REFRESH IMEDIATO APÓS CRIAR DEMANDA
                console.log('🔄 Atualizando listas após criar nova demanda...');
                
                // Ir para a tela de minhas demandas
                showSection('my-requests');
                
                // Aguardar um pouco e forçar refresh
                setTimeout(async () => {
                    await loadDemandsFromApi(); // Recarregar do servidor
                    await renderMyRequests(); // Re-renderizar a tela
                    console.log('✅ Listas atualizadas automaticamente!');
                }, 500); // Pequeno delay para garantir que o servidor processou
                
            } else {
                throw new Error('Falha ao salvar demanda');
            }
        } catch (error) {
            console.error('❌ Erro ao criar demanda:', error);
            showToast('Erro ao criar demanda: ' + error.message, 'error');
        }
    };

    // ===== UTILITÁRIAS =====

    const updateUserInfo = async () => {
        try {
            const users = getUsers();
            let user = users.find(u => u.username === currentUser);
            
            // Se não encontrar o usuário nos dados da API, criar um temporário com role da API
            if (!user) {
                console.log(`⚠️ Usuário ${currentUser} não encontrado na base, criando perfil temporário`);
                user = {
                    username: currentUser,
                    name: currentUser, // Usar o username como nome
                    role: currentUserRole // Usar role detectada pela API de autenticação
                };
            } else {
                // Usar role da API se disponível, senão usar role do banco
                user.role = currentUserRole;
            }
            
            if (currentUserNameSpan) currentUserNameSpan.textContent = user.name;
            if (currentUserRoleSpan) currentUserRoleSpan.textContent = getRoleLabel(user.role);
            if (adminPanelNavItem) adminPanelNavItem.style.display = user.role === 'admin' ? 'block' : 'none';
            if (focalPanelNavItem) focalPanelNavItem.style.display = hasFocalPermissions(user.role) ? 'block' : 'none';
            
            console.log(`👤 Interface atualizada para: ${user.name} (${user.role})`);
        } catch (error) {
            console.error('❌ Erro ao atualizar informações do usuário:', error);
            // Fallback básico
            if (currentUserNameSpan) currentUserNameSpan.textContent = currentUser;
            if (currentUserRoleSpan) currentUserRoleSpan.textContent = 'Colaborador';
        }
    };

    const showSection = (sectionId) => {
        document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
        const navElement = document.getElementById('nav-' + sectionId);
        if (navElement) navElement.classList.add('active');
        appContent.style.opacity = '0';
        setTimeout(() => { appContent.style.opacity = '1'; }, 100);
    };

    // ✅ FUNÇÃO CORRIGIDA PARA FORMATAR DATA (SEM PROBLEMAS DE TIMEZONE)
    const formatDate = (dateString) => {
        if (!dateString || dateString === 'undefined' || dateString === 'null') {
            return 'Data inválida';
        }
        try {
            const date = new Date(dateString);
            
            // Verificar se a data é válida
            if (isNaN(date.getTime())) {
                return 'Data inválida';
            }
            
            // ✅ CORREÇÃO: Usar apenas toLocaleDateString sem timezone (evita conversões)
            return date.toLocaleDateString('pt-BR');
        } catch (error) {
            console.error('Erro ao formatar data:', error, 'Input:', dateString);
            return 'Data inválida';
        }
    };

    // ✅ FUNÇÃO CORRIGIDA PARA FORMATAR HORA (SEM PROBLEMAS DE TIMEZONE)
    const formatTime = (dateString) => {
        if (!dateString || dateString === 'undefined' || dateString === 'null') {
            return '00:00';
        }
        try {
            const date = new Date(dateString);
            
            // Verificar se a data é válida
            if (isNaN(date.getTime())) {
                return '00:00';
            }
            
            // ✅ CORREÇÃO: Usar apenas toLocaleTimeString sem timezone
            return date.toLocaleTimeString('pt-BR', { 
                hour: '2-digit', 
                minute: '2-digit'
            });
        } catch (error) {
            console.error('Erro ao formatar hora:', error, 'Input:', dateString);
            return '00:00';
        }
    };

    // ✅ FUNÇÃO CORRIGIDA PARA FORMATAR DATA E HORA COMPLETA (SEM TIMEZONE FORÇADO)
    const formatDateTime = (dateString) => {
        if (!dateString || dateString === 'undefined' || dateString === 'null') {
            return 'Data inválida';
        }
        try {
            const date = new Date(dateString);
            
            // Verificar se a data é válida
            if (isNaN(date.getTime())) {
                return 'Data inválida';
            }
            
            // ✅ CORREÇÃO: Usar formatação local sem forçar timezone
            const dataFormatada = date.toLocaleDateString('pt-BR');
            const horaFormatada = date.toLocaleTimeString('pt-BR', {
                hour: '2-digit',
                minute: '2-digit'
            });
            
            return `${dataFormatada} às ${horaFormatada}`;
        } catch (error) {
            console.error('Erro ao formatar data/hora:', error, 'Input:', dateString);
            return 'Data inválida';
        }
    };

    const calculateAging = (dateString) => {
        const created = new Date(dateString);
        const now = new Date();
        const diffTime = Math.abs(now - created);
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        return `${diffDays} dias`;
    };

    // Função getUserName
    const getUserName = (username) => {
        // Tratar valores undefined, null, ou vazios
        if (!username || username === 'undefined' || username === 'null') {
            return 'Sistema';
        }
        
        // SEMPRE usar dados reais da API - buscar no cache de usuários da API
        if (usersCache && usersCache.length > 0) {
            const user = usersCache.find(u => u.id === username || u.username === username);
            if (user) {
                return user.name || username;
            }
        }
        
        // ✅ FALLBACK: Mapeamento local com dados REAIS dos usuários
        const userMapping = {
            // Usuários Windows (minúsculas - como vem do Windows)
            'a0162350': 'João',
            'a0125079': 'Maria Daniela', 
            'g0040925': 'Fabiano k',
            'g0055237': 'Kananda',
            'a0075020': 'Agatha',
            'a0074849': 'Johnny',
            'r338561': 'Gabi Mazolla',
            
            // Versões maiúsculas (backup)
            'A0162350': 'João',
            'A0125079': 'Maria Daniela', 
            'G0040925': 'Fabiano k',
            'G0055237': 'Kananda',
            'A0075020': 'Agatha',
            'A0074849': 'Johnny',
            'R338561': 'Gabi Mazolla'
        };
        
        // Buscar no mapeamento local (case insensitive)
        const lowerUsername = username.toLowerCase();
        const upperUsername = username.toUpperCase();
        const mappedName = userMapping[username] || userMapping[lowerUsername] || userMapping[upperUsername];
        
        if (mappedName) {
            return mappedName;
        }
        
        // Se não encontrou em lugar nenhum, retornar username original
        console.warn('⚠️ Usuário não encontrado:', username);
        return username;
    };

    // ✅ Função para obter role do usuário (admin/focal fallback)
    const getUserRole = (username) => {
        if (!username) return 'user';
        
        // SEMPRE usar dados reais da API primeiro
        if (usersCache && usersCache.length > 0) {
            const user = usersCache.find(u => u.id === username || u.username === username);
            if (user && user.role) {
                return user.role;
            }
        }
        
        // ✅ FALLBACK: Roles APENAS para usuários conhecidos (todos admin)
        const userRoles = {
            // Usuários Windows (minúsculas)
            'g0040925': 'admin',    // Fabiano k
            'g0055237': 'admin',    // Kananda  
            'a0162350': 'admin',    // João
            'a0125079': 'admin',    // Maria Daniela
            'a0075020': 'admin',    // Agatha
            'a0074849': 'admin',    // Johnny
            'r338561': 'admin',     // Gabi Mazolla
            
            // Versões maiúsculas (backup)
            'G0040925': 'admin',    // Fabiano k
            'G0055237': 'admin',    // Kananda
            'A0162350': 'admin',    // João
            'A0125079': 'admin',    // Maria Daniela
            'A0075020': 'admin',    // Agatha
            'A0074849': 'admin',    // Johnny
            'R338561': 'admin'      // Gabi Mazolla
        };
        
        const lowerUsername = username.toLowerCase();
        const upperUsername = username.toUpperCase();
        
        // ✅ REGRA: Se não estiver na lista = 'user' (usuário comum)
        return userRoles[username] || userRoles[lowerUsername] || userRoles[upperUsername] || 'user';
    };

    // ✅ Função para verificar se é admin ou focal (admin = admin + focal)
    const isAdminOrFocal = (role) => {
        return role === 'admin' || role === 'focal';
    };

    // ✅ Função para verificar se tem permissões de focal (admin também conta)
    const hasFocalPermissions = (role) => {
        return role === 'admin' || role === 'focal';
    };

    // Função para atualizar cache de usuários
    const updateUsersCache = async () => {
        try {
            // Garantir que os usuários são carregados da API
            await loadUsersFromApi();
            console.log('✅ Cache de usuários atualizado');
        } catch (error) {
            console.error('🚨 ERRO ao atualizar cache de usuários:', error);
            throw error; // Não permitir fallback para mock
        }
    };

    const getRoleLabel = (role) => ({ admin: 'Administrador', focal: 'Focal', colaborador: 'Colaborador' }[role] || role);

    const generateGroupStats = () => {
        const groupStats = {};
        getDemands().forEach(demand => { 
            const group = demand.group_name || demand.group || 'Sem Grupo';
            groupStats[group] = (groupStats[group] || 0) + 1; 
        });
        return Object.entries(groupStats).map(([group, count]) => `
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span>${group}</span><span class="badge-soft blue">${count}</span>
            </div>
        `).join('');
    };

    // === FUNÇÃO DE VERIFICAÇÃO DE PERMISSÕES ===
    const getUserPermissions = async (userId) => {
        try {
            // Método 1: Tentar buscar permissões da API
            try {
                const response = await fetch(`/api/users/${userId}/permissions`, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                });
                
                if (response.ok) {
                    const data = await response.json();
                    if (data.success && data.permissions) {
                        console.log(`🔐 Permissões obtidas da API para ${userId}:`, data.permissions);
                        return data.permissions;
                    }
                }
            } catch (e) {
                console.log('⚠️ API de permissões não disponível, usando fallback...');
            }
            
            // Método 2: Fallback para permissões hardcoded
            const userIdLower = (userId || '').toLowerCase();
            const isKruet = userIdLower === 'kruet';
            
            // Lista de usuários admin/focal (hardcoded para garantir funcionamento)
            const adminUsers = ['kruet', 'g0040925', 'fabia', 'a0074849', 'a0070320', 'a0125079', 'a0162350', 'g0040923', 'g005523', 'r338561'];
            const focalUsers = ['kruet', 'g005523', 'a0094512', 'a0074849', 'a0125079', 'a0075020', 'g0040902', 'a0162350', 'a0070320', 'g0040923', 'r338561'];
            
            const isAdmin = adminUsers.some(admin => admin.toLowerCase() === userIdLower);
            const isFocal = focalUsers.some(focal => focal.toLowerCase() === userIdLower);
            
            // Role final: admin se for admin direto OU focal
            const finalRole = (isAdmin || isFocal || isKruet) ? 'admin' : 'colaborador';
            
            console.log(`🔐 Verificação de permissões para ${userId}:`);
            console.log(`  - É kruet: ${isKruet}`);
            console.log(`  - É admin: ${isAdmin}`);
            console.log(`  - É focal: ${isFocal}`);
            console.log(`  - Role final: ${finalRole}`);
            console.log(`  - Pode exportar: TRUE (todos podem exportar)`);
            
            return {
                userId: userId,
                role: finalRole,
                isAdmin: finalRole === 'admin',
                isFocal: isFocal || isKruet,
                canExport: true, // TODOS os usuários podem exportar
                canViewAll: finalRole === 'admin',
                canEditAll: finalRole === 'admin'
            };
        } catch (error) {
            console.error('Erro ao verificar permissões:', error);
            return {
                userId: userId,
                role: 'colaborador',
                isAdmin: false,
                isFocal: false,
                canExport: true, // TODOS podem exportar
                canViewAll: false,
                canEditAll: false
            };
        }
    };

    // === FUNÇÃO DE EXPORT EXCEL ===
    const exportToExcel = async () => {
        try {
            console.log('📊 INICIANDO EXPORT PARA EXCEL...');
            console.log('👤 Usuário atual:', currentUser);
            
                    const permissions = await getUserPermissions(currentUser);
        console.log('🔐 Permissões do usuário:', permissions);
            
            // Todos podem exportar
            console.log('✅ Usuário pode exportar, buscando dados do banco...');
            
            // Buscar dados do endpoint específico de export
            let exportData = [];
            try {
                console.log('📡 Buscando dados de export da API...');
                const response = await fetch(`${API_BASE_URL}/export`, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                });
                
                if (response.ok) {
                    const data = await response.json();
                    const demands = data.data || [];
                    console.log(`✅ ${demands.length} demandas carregadas para export`);
                    
                    // ✅ MAPEAR APENAS AS COLUNAS ESPECÍFICAS SOLICITADAS
                    exportData = demands.map(demand => ({
                        'id': demand.id || '',
                        'requester': demand.requester || '',
                        'categoria': demand.categoria || '',
                        'group_name': demand.group_name || '',
                        'scenario': demand.scenario || '',
                        'observation': (demand.observation || '').replace(/[\r\n]/g, ' ').replace(/,/g, ';'),
                        'open_date': demand.open_date ? formatDate(demand.open_date) : '',
                        'status': demand.status || '',
                        'responsible': demand.responsible || '',
                        'deadline': demand.deadline ? formatDate(demand.deadline) : '',
                        'priority': demand.priority || '',
                        'priority_classification': demand.priority_classification || '',
                        'priority_score': demand.priority_score || 0,
                        'impacto_cliente_final': demand.impacto_cliente_final || '',
                        'complexidade_tecnica': demand.complexidade_tecnica || '',
                        'tdna': demand.tdna || '',
                        'nps': demand.nps || '',
                        'reincidencia': demand.reincidencia || '',
                        'reclamada': demand.reclamada || '',
                        'frequencia_automacao': demand.frequencia_automacao || '',
                        'gestao_equipes_direta': demand.gestao_equipes_direta || '',
                        'envolvimento_grupos': demand.envolvimento_grupos || '',
                        'gerar_dentro_casa': demand.gerar_dentro_casa || '',
                        'created_at': demand.created_at ? formatDateTime(demand.created_at) : '',
                        'updated_at': demand.updated_at ? formatDateTime(demand.updated_at) : '',
                        'theme': demand.theme || '',
                        'title': demand.title || '',
                        'description': (demand.description || '').replace(/[\r\n]/g, ' ').replace(/,/g, ';'),
                        'due_date': demand.due_date ? formatDate(demand.due_date) : '',
                        'real_demand_id': demand.real_demand_id || '',
                        'submotivo': demand.submotivo || ''
                    }));
                    
                } else {
                    throw new Error(`API retornou status ${response.status}`);
                }
            } catch (apiError) {
                console.log('⚠️ API não disponível, usando dados locais...');
                // ✅ EXPORT SIMPLIFICADO - Apenas dados da tabela demands
                const localDemands = getDemands();
                const categoryRanking = buildCategoryRankingMap();
                
                // ✅ EXPORT EXCEL - COLUNAS ESPECÍFICAS CONFORME SOLICITADO
                exportData = localDemands.map(demand => {
                    const categoryInfo = getCategoriaFromScenario(demand.scenario);
                    
                    return {
                        'id': demand.id || '',
                        'requester': demand.requester || '',
                        'categoria': demand.categoria || categoryInfo.categoria,
                        'group_name': demand.group_name || '',
                        'scenario': demand.scenario || '',
                        'observation': (demand.observation || '').replace(/[\r\n]/g, ' ').replace(/,/g, ';'),
                        'open_date': demand.open_date ? formatDate(demand.open_date) : '',
                        'status': demand.status || '',
                        'responsible': demand.responsible || '',
                        'deadline': demand.deadline ? formatDate(demand.deadline) : '',
                        'priority': demand.priority || '',
                        'priority_classification': demand.priority_classification || '',
                        'priority_score': demand.priority_score || demand.analyticsScore || 0,
                        'impacto_cliente_final': demand.impacto_cliente_final || '',
                        'complexidade_tecnica': demand.complexidade_tecnica || '',
                        'tdna': demand.tdna || '',
                        'nps': demand.nps || '',
                        'reincidencia': demand.reincidencia || '',
                        'reclamada': demand.reclamada || '',
                        'frequencia_automacao': demand.frequencia_automacao || '',
                        'gestao_equipes_direta': demand.gestao_equipes_direta || '',
                        'envolvimento_grupos': demand.envolvimento_grupos || '',
                        'gerar_dentro_casa': demand.gerar_dentro_casa || '',
                        'created_at': demand.created_at ? formatDateTime(demand.created_at) : '',
                        'updated_at': demand.updated_at ? formatDateTime(demand.updated_at) : '',
                        'theme': demand.theme || '',
                        'title': demand.title || '',
                        'description': (demand.description || '').replace(/[\r\n]/g, ' ').replace(/,/g, ';'),
                        'due_date': demand.due_date ? formatDate(demand.due_date) : ''
                    };
                });
            }
            
            if (exportData.length === 0) {
                showToast('❌ Nenhuma demanda encontrada para exportar', 'error');
                return;
            }
            
            console.log(`📊 Preparando export de ${exportData.length} demandas...`);
            
            // Converter para CSV (compatível com Excel)
            const headers = Object.keys(exportData[0]);
            let csvContent = '\ufeff'; // BOM para UTF-8
            csvContent += headers.join(',') + '\n';
            
            exportData.forEach(row => {
                const values = headers.map(header => {
                    let value = row[header] || '';
                    // Escapar aspas e adicionar aspas se necessário
                    if (typeof value === 'string' && (value.includes(',') || value.includes('"') || value.includes('\n'))) {
                        value = '"' + value.replace(/"/g, '""') + '"';
                    }
                    return value;
                });
                csvContent += values.join(',') + '\n';
            });
            
            // Download do arquivo
            const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
            const link = document.createElement('a');
            const url = URL.createObjectURL(blob);
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-').split('T')[0];
            link.setAttribute('href', url);
            link.setAttribute('download', `demandas_export_${timestamp}.csv`);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            URL.revokeObjectURL(url);
            
            showToast(`📊 Export realizado com sucesso! ${exportData.length} demandas exportadas.`, 'success');
            console.log(`✅ Export concluído: ${exportData.length} registros com timeline`);
            
        } catch (error) {
            console.error('❌ Erro no export:', error);
            showToast('Erro ao exportar dados. Verifique o console.', 'error');
        }
    };

    const showToast = (message, type = 'info') => {
        const toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            console.warn('Container de toast não encontrado');
            return;
        }
        
        const toastId = 'toast-' + Date.now();
        const toast = document.createElement('div');
        toast.className = `toast ${type === 'success' ? 'bg-success' : type === 'error' ? 'bg-danger' : 'bg-info'} text-white`;
        toast.id = toastId;
        toast.innerHTML = `<div class="toast-header"><strong class="me-auto">Sistema</strong><button type="button" class="btn-close btn-close-white" data-action="toast-close"></button></div><div class="toast-body">${message}</div>`;
        toastContainer.appendChild(toast);
        
        // Fallback manual se Bootstrap não estiver disponível
        if (hasBootstrap && bootstrap.Toast) {
            try {
                const bsToast = new bootstrap.Toast(toast);
                bsToast.show();
            } catch (e) {
                console.warn('Erro ao criar toast Bootstrap, usando fallback:', e);
                showToastFallback(toast);
            }
        } else {
            showToastFallback(toast);
        }
        
        // Auto-remove após 3.5 segundos
        setTimeout(() => { 
            if (toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
        }, 3500);
    };

    // ✅ TORNAR showToast GLOBAL
    window.showToast = showToast;

    // ✅ TORNAR FUNÇÕES DE RENDERIZAÇÃO GLOBAIS
    window.renderMyRequests = renderMyRequests;
    window.renderGeneralDemands = renderGeneralDemands;

    // Fallback para toast sem Bootstrap
    const showToastFallback = (toast) => {
        toast.style.display = 'block';
        toast.style.opacity = '1';
        toast.style.transform = 'translateX(0)';
        
        // Adicionar listener para fechar manualmente
        const closeBtn = toast.querySelector('[data-action="toast-close"]');
        if (closeBtn) {
            closeBtn.addEventListener('click', () => {
                if (toast.parentNode) {
                    toast.parentNode.removeChild(toast);
                }
            });
        }
    };

    // Re-renderizar a visão atual (melhorado com logs e tratamento de erros)
    const refreshCurrentView = async () => {
        try {
            const activeId = document.querySelector('.nav-link.active')?.id;
            console.log(`🔄 Atualizando tela atual: ${activeId}`);
            
            switch (activeId) {
                case 'nav-my-requests':
                    console.log('📋 Atualizando Minhas Demandas...');
                    await renderMyRequests();
                    break;
                case 'nav-focal-panel':
                    console.log('📋 Atualizando Painel Focal...');
                    await renderFocalPanel();
                    break;
                case 'nav-admin-panel':
                    console.log('📋 Atualizando Painel Admin...');
                    await renderAdminPanel();
                    break;
                case 'nav-general-demands':
                    console.log('📋 Atualizando Demandas Gerais...');
                    await renderGeneralDemands();
                    break;
                case 'nav-analytics-ranking':
                    console.log('📊 Atualizando Analytics & Ranking...');
                    await renderAnalyticsRanking();
                    break;
                case 'nav-home':
                    console.log('🏠 Atualizando Home...');
                    await renderHome();
                    break;
                default:
                    console.log('🔴 Nenhuma navegação ativa identificada para refresh');
                    break;
            }
            
            console.log('✅ Tela atualizada com sucesso!');
            
        } catch (error) {
            console.error('❌ Erro ao atualizar tela atual:', error);
            // Não lançar erro para não quebrar o auto-refresh
        }
    };

    // Navegação (com verificação de segurança)
    document.getElementById('nav-home')?.addEventListener('click', (e) => { e.preventDefault(); showSection('home'); renderHome(); });
    document.getElementById('nav-new-request')?.addEventListener('click', (e) => { 
        e.preventDefault(); 
        console.log('🔄 Navegando para Nova Demanda...');
        showSection('new-request'); 
        renderNewRequestForm(); 
    });
    document.getElementById('nav-my-requests')?.addEventListener('click', (e) => { e.preventDefault(); showSection('my-requests'); renderMyRequests(); });
    document.getElementById('nav-general-demands')?.addEventListener('click', (e) => { e.preventDefault(); showSection('general-demands'); renderGeneralDemands(); });
    document.getElementById('nav-focal-panel')?.addEventListener('click', (e) => { e.preventDefault(); showSection('focal-panel'); renderFocalPanel(); });
    document.getElementById('nav-admin-panel')?.addEventListener('click', (e) => { e.preventDefault(); showSection('admin-panel'); renderAdminPanel(); });
    document.getElementById('nav-analytics-ranking')?.addEventListener('click', (e) => { e.preventDefault(); showSection('analytics-ranking'); renderAnalyticsRanking(); });
    document.getElementById('nav-help')?.addEventListener('click', (e) => {
        e.preventDefault();
        const el = document.getElementById('helpModal');
        if (!el) return;
        if (typeof window.bootstrap !== 'undefined') {
            new bootstrap.Modal(el).show();
        } else {
            // fallback com backdrop
            let backdrop = document.createElement('div');
            backdrop.className = 'modal-backdrop fade show';
            document.body.appendChild(backdrop);
            el.style.display = 'block';
            el.classList.add('show');
            el.removeAttribute('aria-hidden');
            const closeFn = () => {
                el.style.display = 'none'; el.classList.remove('show'); el.setAttribute('aria-hidden', 'true');
                backdrop && backdrop.parentNode && backdrop.parentNode.removeChild(backdrop);
            };
            el.querySelectorAll('[data-bs-dismiss="modal"], .btn-close').forEach(btn => btn.addEventListener('click', closeFn, { once: true }));
            backdrop.addEventListener('click', closeFn, { once: true });
        }
    });

    // ===== FUNÇÕES GLOBAIS =====

    // Navegações rápidas expostas globalmente
    // Funções globais para onclick (devido ao CSP)
    window.exportToExcel = exportToExcel;
    
    window.gotoNewRequest = () => {
        try {
            console.log('🚀 gotoNewRequest: Navegando para Nova Demanda...');
            showSection('new-request');
            renderNewRequestForm();
        } catch (e) {
            console.error('❌ Erro ao abrir Nova Demanda:', e);
        }
    };
    
    window.gotoMyDemands = () => {
        try {
            console.log('📋 gotoMyDemands: Navegando para Minhas Demandas...');
            showSection('my-requests');
            renderMyRequests();
        } catch (e) {
            console.error('❌ Erro ao abrir Minhas Demandas:', e);
        }
    };
    
    window.gotoFocalPanel = () => { 
        console.log('🎯 gotoFocalPanel: Navegando para Demandas Atribuídas...');
        showSection('focal-panel'); 
        renderFocalPanel(); 
    };
    
    window.gotoGeneralDemands = () => { 
        console.log('📊 gotoGeneralDemands: Navegando para Demandas Gerais...');
        showSection('general-demands'); 
        renderGeneralDemands(); 
    };

    // Trocar usuário
    window.switchUser = (username) => { 
        currentUser = username; 
        updateUserInfo(); 
        renderHome(); 
        showToast(`Usuário alterado para: ${getUserName(username)}`, 'info'); 
    };

    // Delegação global para botões "Ver" da timeline
    document.addEventListener('click', (event) => {
        const btn = event.target.closest('[data-action="view-timeline"]');
        if (btn) {
            event.preventDefault();
            const idAttr = btn.getAttribute('data-id') || '';
            const demandId = parseInt(idAttr.toString().replace(/[^0-9]/g, ''), 10);
            if (!isNaN(demandId) && typeof window.viewTimeline === 'function') {
                window.viewTimeline(demandId);
            } else {
                console.error('Botão Ver: id inválido ou função não disponível', { idAttr, demandId });
                showToast('Não foi possível abrir a timeline. Tente novamente.', 'error');
            }
        }

        // ✅ NOVO: Handler para editar ID da demanda
        const editIdBtn = event.target.closest('[data-action="edit-demand-id"]');
        if (editIdBtn) {
            event.preventDefault();
            const demandId = editIdBtn.getAttribute('data-id');
            const currentValue = editIdBtn.closest('tr').querySelector('td:nth-child(3) .badge').textContent.trim();
            
            showEditModal(
                'Editar ID da Demanda Real',
                'Digite o novo ID da demanda real:',
                currentValue === 'N/A' ? '' : currentValue,
                'text',
                (newValue) => updateDemandField(demandId, 'real_demand_id', newValue)
            );
        }

        // ✅ NOVO: Handler para editar data de abertura
        const editDateBtn = event.target.closest('[data-action="edit-demand-date"]');
        if (editDateBtn) {
            event.preventDefault();
            const demandId = editDateBtn.getAttribute('data-id');
            
            // Detectar qual tabela estamos (diferentes posições de coluna)
            const activeSection = document.querySelector('.nav-link.active')?.id;
            let dateColumnIndex;
            
            if (activeSection === 'nav-my-requests') {
                dateColumnIndex = 10; // Minhas Demandas: Data Abertura é a 10ª coluna
            } else if (activeSection === 'nav-general-demands') {
                dateColumnIndex = 9; // Demandas Gerais: Data Abertura é a 9ª coluna
            } else {
                dateColumnIndex = 10; // Default
            }
            
            // Pegar a data atual da tabela
            const currentDateCell = editDateBtn.closest('tr').querySelector(`td:nth-child(${dateColumnIndex})`);
            const currentDateText = currentDateCell ? currentDateCell.textContent.trim() : '';
            
            // Tentar converter a data para formato YYYY-MM-DD
            let currentDate = '';
            if (currentDateText) {
                try {
                    // Assumir formato brasileiro DD/MM/YYYY ou similar
                    const parts = currentDateText.split(/[\/\-\.]/);
                    if (parts.length === 3) {
                        // Assumir DD/MM/YYYY
                        const day = parts[0].padStart(2, '0');
                        const month = parts[1].padStart(2, '0');
                        const year = parts[2];
                        currentDate = `${year}-${month}-${day}`;
                    }
                } catch (e) {
                    console.log('Erro ao converter data:', e);
                }
            }
            
            showEditModal(
                'Editar Data de Abertura',
                'Selecione a nova data de abertura:',
                currentDate,
                'date',
                (newValue) => updateDemandField(demandId, 'open_date', newValue)
            );
        }
        
        // Handler para botão Nova Demanda
        const newRequestBtn = event.target.closest('[data-action="new-request"]');
        if (newRequestBtn) {
            event.preventDefault();
            console.log('🚀 Clique detectado em Nova Demanda via event listener');
            if (typeof window.gotoNewRequest === 'function') {
                window.gotoNewRequest();
            } else {
                console.error('Função gotoNewRequest não encontrada');
                showToast('Erro ao abrir Nova Demanda', 'error');
            }
        }
        
        // Handler para botão Minhas Demandas
        const myRequestsBtn = event.target.closest('[data-action="my-requests"]');
        if (myRequestsBtn) {
            event.preventDefault();
            console.log('📋 Clique detectado em Minhas Demandas via event listener');
            if (typeof window.gotoMyDemands === 'function') {
                window.gotoMyDemands();
            } else {
                console.error('Função gotoMyDemands não encontrada');
                showToast('Erro ao abrir Minhas Demandas', 'error');
            }
        }
    });

    // Helpers para abrir/fechar modal sem Bootstrap (CSP bloqueia inline)
    const showModalFallback = (modalEl) => {
        if (!modalEl) return;
        // cria backdrop simples
        let bd = document.createElement('div');
        bd.className = 'modal-backdrop fade show';
        document.body.appendChild(bd);
        modalEl.style.display = 'block';
        modalEl.classList.add('show');
        modalEl.removeAttribute('aria-hidden');
        const close = () => {
            modalEl.style.display = 'none';
            modalEl.classList.remove('show');
            modalEl.setAttribute('aria-hidden', 'true');
            bd && bd.parentNode && bd.parentNode.removeChild(bd);
        };
        // botões de fechar
        modalEl.querySelectorAll('[data-bs-dismiss="modal"], .btn-close, .btn-secondary').forEach(el => {
            el.addEventListener('click', close, { once: true });
        });
        // esc
        document.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(); }, { once: true });
    };

    const hideModalAny = (modalEl) => {
        if (!modalEl) return;
        try {
            if (window.bootstrap && bootstrap.Modal.getInstance) {
                const inst = bootstrap.Modal.getInstance(modalEl) || new bootstrap.Modal(modalEl);
                inst.hide();
                return;
            }
        } catch (_) {}
        // fallback
        modalEl.style.display = 'none';
        modalEl.classList.remove('show');
        modalEl.setAttribute('aria-hidden', 'true');
        const bd = document.querySelector('.modal-backdrop');
        if (bd && bd.parentNode) bd.parentNode.removeChild(bd);
    };

    // Delegação para ações dentro do modal (CSP bloqueia inline onclick)
    document.addEventListener('click', (event) => {
        const addBtn = event.target.closest('[data-action="add-observation"]');
        if (addBtn) {
            event.preventDefault();
            if (typeof window.addTimelineInteraction === 'function') window.addTimelineInteraction();
            return;
        }
        const updBtn = event.target.closest('[data-action="update-status"]');
        if (updBtn) {
            event.preventDefault();
            if (typeof window.updateDemandStatus === 'function') window.updateDemandStatus();
            return;
        }
        
        // ✅ NOVO: Botão para atualizar informações da demanda
        const updInfoBtn = event.target.closest('[data-action="update-demand-info"]');
        if (updInfoBtn) {
            event.preventDefault();
            if (typeof window.updateDemandInfo === 'function') window.updateDemandInfo();
            return;
        }
        const closeBtn = event.target.closest('[data-action="modal-close"], [data-bs-dismiss="modal"], .btn-close');
        if (closeBtn) {
            event.preventDefault();
            // Encontrar o modal pai
            const modalEl = closeBtn.closest('.modal') || document.getElementById('timelineModal') || document.getElementById('redistributeModal') || document.getElementById('classificationModal') || document.getElementById('helpModal');
            if (modalEl) {
                hideModalAny(modalEl);
            }
            return;
        }
        const goMy = event.target.closest('[data-action="goto-my-requests"]');
        if (goMy) {
            event.preventDefault();
            showSection('my-requests');
            renderMyRequests();
            return;
        }
        const goNew = event.target.closest('[data-action="goto-new-request"]');
        if (goNew) {
            event.preventDefault();
            showSection('new-request');
            renderNewRequestForm();
            return;
        }
        const openRedist = event.target.closest('[data-action="open-redistribute"]');
        if (openRedist) {
            event.preventDefault();
            const idAttr = openRedist.getAttribute('data-id') || '';
            const demandId = parseInt(idAttr.toString().replace(/[^0-9]/g,''), 10);
            if (!isNaN(demandId) && typeof window.showRedistributeModal === 'function') {
                window.showRedistributeModal(demandId);
            }
            return;
        }
        const confirmRedist = event.target.closest('[data-action="confirm-redistribute"]');
        if (confirmRedist) {
            event.preventDefault();
            if (typeof window.confirmRedistribute === 'function') window.confirmRedistribute();
            return;
        }
        // Remoção: switch-user não é mais suportado em produção
        // O usuário é detectado automaticamente
        const submitClass = event.target.closest('[data-action="submit-classification"]');
        if (submitClass) {
            event.preventDefault();
            if (typeof window.submitClassification === 'function') window.submitClassification();
            return;
        }
        const goFocal = event.target.closest('[data-action="goto-focal"]');
        if (goFocal) {
            event.preventDefault();
            showSection('focal-panel');
            renderFocalPanel();
            return;
        }
        const goGeneral = event.target.closest('[data-action="goto-general"]');
        if (goGeneral) {
            event.preventDefault();
            showSection('general-demands');
            renderGeneralDemands();
            return;
        }
        
        // Fechar toast
        const toastClose = event.target.closest('[data-action="toast-close"]');
        if (toastClose) {
            event.preventDefault();
            const toast = toastClose.closest('.toast');
            if (toast && toast.parentNode) {
                toast.parentNode.removeChild(toast);
            }
            return;
        }
        
        // Debug: log de ações não reconhecidas
        const anyAction = event.target.closest('[data-action]');
        if (anyAction && !['add-observation', 'update-status', 'modal-close', 'goto-my-requests', 'goto-new-request', 'open-redistribute', 'confirm-redistribute', 'switch-user', 'submit-classification', 'goto-focal', 'goto-general', 'toast-close'].includes(anyAction.dataset.action)) {
            console.log('Ação não reconhecida:', anyAction.dataset.action, anyAction);
        }
    });

    // Visualizar timeline
    // Visualizar timeline
    window.viewTimeline = async (demandId) => {
        try {
            console.log('🔍 [FRONTEND] Iniciando viewTimeline para demanda:', demandId);
            
            currentDemandId = demandId;
            currentTimelineViewDemandId = demandId; // Para o auto-refresh
            timelineModalOpen = true; // Marcar modal como aberto
            
            console.log('📊 [FRONTEND] Buscando demandas...');
            const demands = await getDemands();
            console.log('📊 [FRONTEND] Demandas recebidas:', demands ? demands.length : 'null');
            
            const demand = demands.find(d => d.id === demandId);
            
            if (!demand) {
                console.error('❌ [FRONTEND] Demanda não encontrada:', demandId);
                showToast('Demanda não encontrada', 'error');
                return;
            }

            console.log('✅ [FRONTEND] Demanda encontrada:', {
                id: demand.id,
                scenario: demand.scenario,
                timeline_length: demand.timeline ? demand.timeline.length : 'sem timeline'
            });

            // ✅ CORREÇÃO: Usar timeline que já vem carregada do backend OU buscar via API
            console.log('📅 [FRONTEND] Carregando timeline da demanda', demandId);
            
            let timeline = [];
            
            // Primeiro, tentar usar timeline já carregada
            if (demand.timeline && Array.isArray(demand.timeline) && demand.timeline.length > 0) {
                timeline = demand.timeline;
                console.log(`✅ [FRONTEND] Timeline do cache: ${timeline.length} eventos`);
            } else {
                console.log('⚠️ [FRONTEND] Timeline não encontrada no cache, buscando via API...');
                try {
                    // Buscar timeline específica da demanda via API
                    console.log(`📡 [FRONTEND] Fazendo request para /demands/${demandId}/timeline`);
                    const timelineResult = await apiRequest(`/demands/${demandId}/timeline`);
                    console.log('📡 [FRONTEND] Resposta da API:', timelineResult);
                    
                    if (timelineResult && timelineResult.success && timelineResult.data) {
                        // ADAPTAÇÃO: Mapear colunas existentes para o formato esperado
                        timeline = timelineResult.data.map(event => ({
                            id: event.id,
                            demand_id: event.demand_id,
                            usuario: event.user_name || event.user_id || 'Sistema',
                            acao: event.event_text,
                            descricao: event.event_text,
                            data_acao: event.event_date,
                            created_at: event.created_at
                        }));
                        console.log(`✅ [FRONTEND] Timeline carregada via API: ${timeline.length} eventos`);
                    } else {
                        console.log('⚠️ [FRONTEND] Timeline não encontrada via API, criando entrada inicial...');
                        timeline = [{
                            usuario: 'Sistema',
                            acao: 'Demanda Criada',
                            descricao: `Demanda "${demand.scenario || 'Nova demanda'}" foi criada`,
                            data_acao: demand.open_date || demand.created_at,
                            created_at: demand.created_at
                        }];
                    }
                } catch (error) {
                    console.error('❌ [FRONTEND] Erro ao carregar timeline via API:', error);
                    // Fallback: criar entrada inicial
                    timeline = [{
                        usuario: 'Sistema',
                        acao: 'Demanda Criada', 
                        descricao: `Demanda "${demand.scenario || 'Nova demanda'}" foi criada`,
                        data_acao: demand.open_date || demand.created_at,
                        created_at: demand.created_at
                    }];
                }
            }
            
            // Ordenar timeline por data_acao (como no exemplo funcional)
            timeline.sort((a, b) => new Date(a.data_acao || a.created_at) - new Date(b.data_acao || b.created_at));
            
            console.log('✅ [FRONTEND] Timeline preparada:', timeline.length, 'eventos');

            // Preencher modal de timeline
            console.log('🔧 [FRONTEND] Preenchendo modal...');
            document.getElementById('timeline-demand-id').textContent = demandId;
        
        // Detalhes da demanda (com novos campos)
        document.getElementById('demand-details').innerHTML = `
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-2">
                        <strong>ID Sistema:</strong> <span class="badge bg-secondary">#${demand.id}</span>
                    </div>
                    <div class="mb-2">
                        <strong>ID Real:</strong> <span class="badge bg-info text-dark">${demand.real_demand_id || 'N/A'}</span>
                    </div>
                    <div class="mb-2">
                        <strong>Grupo:</strong> ${demand.group_name || 'N/A'}
                    </div>
                    <div class="mb-2">
                        <strong>Cenário:</strong> ${demand.scenario || 'N/A'}
                    </div>
                    <div class="mb-2">
                        <strong>Submotivo:</strong> <span class="text-primary">${demand.submotivo || 'N/A'}</span>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-2">
                        <strong>Status:</strong> 
                        <span class="badge status-badge status-${(demand.status || 'novo').toLowerCase().replace(' ', '-')}">${demand.status || 'Novo'}</span>
                    </div>
                    <div class="mb-2">
                        <strong>Prioridade:</strong> 
                        <span class="badge priority-${getPriorityCssClass(demand.priority)}">${getPriorityString(demand.priority)}</span>
                        ${demand.analyticsScore ? `<small class="text-primary ms-1">(${demand.analyticsScore}/24pts)</small>` : ''}
                    </div>
                    <div class="mb-2">
                        <strong>Responsável:</strong> ${demand.responsible ? getUserName(demand.responsible) : 'Não atribuído'}
                    </div>
                    <div class="mb-2">
                        <strong>Data de Abertura:</strong> <span class="text-info">${formatDate(demand.open_date || demand.created_at)}</span>
                    </div>
                    <div class="mb-2">
                        <strong>Prazo:</strong> ${formatDeadline(demand.deadline)}
                    </div>
                </div>
            </div>
            <div class="mt-3">
                <strong>Descrição:</strong>
                <div class="p-2 bg-light border rounded">
                    ${demand.observation || demand.description || 'Sem descrição'}
                </div>
            </div>
        `;

        // Timeline events - DESIGN MODERNO COM SCROLL E CONTADOR
        const timelineEvents = document.getElementById('timeline-events');
        if (timelineEvents) {
            console.log('📝 Renderizando timeline moderna com', timeline.length, 'eventos');
            
            if (timeline.length === 0) {
                timelineEvents.innerHTML = `
                    <div class="timeline-empty">
                        <i class="fas fa-clock"></i>
                        <h6>Nenhum evento registrado</h6>
                        <p class="small">Esta demanda ainda não possui histórico de ações</p>
                    </div>
                `;
            } else {
                timelineEvents.innerHTML = `
                    <div class="position-relative">
                        <div class="timeline-counter">
                            ${timeline.length} evento${timeline.length !== 1 ? 's' : ''}
                        </div>
                        <div class="timeline">
                            ${timeline.map((event, index) => {
                                console.log(`📋 Evento ${index + 1}:`, event);
                                const userName = getUserName(event.usuario || 'Sistema');
                                const eventDate = formatDate(event.data_acao || event.created_at);
                                const eventTime = formatTime(event.data_acao || event.created_at);
                                
                                return `
                                    <div class="timeline-item" style="animation-delay: ${index * 0.1}s">
                                        <div class="timeline-content">
                                            <div class="d-flex justify-content-between align-items-start mb-2">
                                                <div class="timeline-user">
                                                    ${userName}
                                                </div>
                                                <div class="timeline-date">
                                                    ${eventDate} às ${eventTime}
                                                </div>
                                            </div>
                                            <p class="mb-1">${event.acao || 'Evento da timeline'}</p>
                                            ${event.descricao && event.descricao !== event.acao ? 
                                                `<div class="text-muted">
                                                    <i class="fas fa-quote-left me-1"></i>
                                                    ${event.descricao}
                                                </div>` : ''}
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    </div>
                `;
                
                // Auto-scroll para o final (evento mais recente) e configurar indicadores
                setTimeout(() => {
                    const timelineContainer = timelineEvents.querySelector('.timeline');
                    if (timelineContainer) {
                        // Scroll para o final
                        timelineContainer.scrollTop = timelineContainer.scrollHeight;
                        
                        // Configurar indicadores de scroll
                        const updateScrollIndicators = () => {
                            const isScrollable = timelineContainer.scrollHeight > timelineContainer.clientHeight;
                            const isAtEnd = Math.abs(timelineContainer.scrollHeight - timelineContainer.clientHeight - timelineContainer.scrollTop) < 3;
                            
                            timelineContainer.classList.toggle('has-scroll', isScrollable && !isAtEnd);
                            timelineContainer.classList.toggle('scroll-end', isScrollable && isAtEnd);
                        };
                        
                        // Verificar inicialmente
                        updateScrollIndicators();
                        
                        // Adicionar listener de scroll
                        timelineContainer.addEventListener('scroll', updateScrollIndicators);
                        
                        // Adicionar efeito de entrada animado aos itens
                        const timelineItems = timelineContainer.querySelectorAll('.timeline-item');
                        timelineItems.forEach((item, index) => {
                            item.style.animationDelay = `${index * 0.1}s`;
                        });
                    }
                }, 100);
            }
            
            console.log('✅ Timeline moderna renderizada no DOM');
        } else {
            console.error('❌ Elemento timeline-events não encontrado no DOM');
        }

        // Mostrar seções de interação baseado em role do usuário e origem da tela
        console.log('🔐 [FRONTEND] Verificando permissões...');
        const users = await getUsers();
        const user = users.find(u => u.username === currentUser) || { 
            username: currentUser, 
            role: currentUserRole  // Usar role detectada pela API
        };
        
        console.log('🔍 [FRONTEND] Buscando elementos DOM das seções...');
        const interactionSection = document.getElementById('timeline-interaction-section');
        const statusUpdateSection = document.getElementById('status-update-section');
        const demandEditSection = document.getElementById('demand-edit-section'); // ✅ NOVA SEÇÃO
        
        console.log('🔍 [FRONTEND] Elementos encontrados:', {
            interactionSection: !!interactionSection,
            statusUpdateSection: !!statusUpdateSection,
            demandEditSection: !!demandEditSection
        });
        
        const activeNavId = document.querySelector('.nav-link.active')?.id;
        const isGeneralView = activeNavId === 'nav-general-demands';
        const isAdminOrFocalUser = hasFocalPermissions(user.role);
        const isRequester = demand.requester === currentUser; // Verificar se é o solicitante

        console.log('🔐 [FRONTEND] Verificando permissões da timeline:');
        console.log(`  - Usuário atual: ${currentUser}`);
        console.log(`  - Solicitante da demanda: ${demand.requester}`);
        console.log(`  - É admin/focal: ${isAdminOrFocalUser}`);
        console.log(`  - É solicitante: ${isRequester}`);
        console.log(`  - Visão geral: ${isGeneralView}`);

        // Se for visão Demandas Gerais e usuário não é admin/focal: somente visualização
        if (isGeneralView && !isAdminOrFocalUser) {
            console.log('👁️ [FRONTEND] Modo somente visualização');
            if (statusUpdateSection) statusUpdateSection.style.display = 'none';
            if (interactionSection) interactionSection.style.display = 'none';
            if (demandEditSection) demandEditSection.style.display = 'none'; // ✅ ESCONDER EDIÇÃO
        } else {
            // Status/Prazo: somente Admin ou Focal
            if (isAdminOrFocalUser) {
                console.log('👤 [FRONTEND] Usuário admin/focal - habilitando funcionalidades administrativas');
                if (statusUpdateSection) statusUpdateSection.style.display = 'block';
                
                const deadlineField = document.getElementById('new-deadline-timeline');
                if (deadlineField) {
                    const today = new Date().toISOString().split('T')[0];
                    deadlineField.min = today;
                    if (demand.deadline) {
                        deadlineField.placeholder = formatDeadline(demand.deadline);
                    }
                }
            } else {
                console.log('👤 [FRONTEND] Usuário padrão - funcionalidades limitadas');
                if (statusUpdateSection) statusUpdateSection.style.display = 'none';
            }

            // ✅ SEÇÃO DE EDIÇÃO DE CAMPOS BÁSICOS: Disponível para TODOS os usuários
            if (demandEditSection) {
                demandEditSection.style.display = 'block';
                console.log('✅ [FRONTEND] Seção de edição habilitada para todos os usuários');
                
                // ✅ PREENCHER CAMPOS ATUAIS
                const editRealIdField = document.getElementById('edit-real-demand-id');
                const editOpenDateField = document.getElementById('edit-open-date');
                
                if (editRealIdField) {
                    editRealIdField.value = demand.real_demand_id || '';
                    editRealIdField.placeholder = demand.real_demand_id ? demand.real_demand_id : 'Ex: DEM-2024-001';
                    console.log('📝 [FRONTEND] Campo ID Real preenchido:', demand.real_demand_id || 'vazio');
                }
                
                if (editOpenDateField) {
                    if (demand.open_date) {
                        // Converter data para formato YYYY-MM-DD
                        const openDate = new Date(demand.open_date);
                        if (!isNaN(openDate.getTime())) {
                            const dateString = openDate.getFullYear() + '-' + 
                                             String(openDate.getMonth() + 1).padStart(2, '0') + '-' + 
                                             String(openDate.getDate()).padStart(2, '0');
                            editOpenDateField.value = dateString;
                            console.log('📅 [FRONTEND] Campo Data Abertura preenchido:', dateString);
                        } else {
                            console.log('� [FRONTEND] Data de abertura inválida, deixando campo vazio');
                        }
                    } else {
                        console.log('📅 [FRONTEND] Campo Data Abertura vazio (usuário pode preencher)');
                    }
                }
                
            } else {
                console.warn('⚠️ [FRONTEND] Elemento demand-edit-section não encontrado no DOM');
            }

            // ✅ NOVA REGRA: Observações podem ser adicionadas por:
            // 1. Admin/Focal (em qualquer demanda)
            // 2. Solicitante (apenas nas suas próprias demandas)
            const canAddObservation = isAdminOrFocalUser || isRequester;
            if (interactionSection) {
                interactionSection.style.display = canAddObservation ? 'block' : 'none';
            }
            
            console.log(`  - Pode adicionar observação: ${canAddObservation}`);
            console.log(`  - Pode editar informações: ${isAdminOrFocalUser}`);
            
            // Atualizar o texto do card para deixar claro a regra
            const observationHeader = document.querySelector('#timeline-interaction-section .card-header h6');
            if (observationHeader && isRequester && !isAdminOrFocalUser) {
                observationHeader.innerHTML = '<i class="fas fa-comment me-2" style="color: #6f42c1;"></i>Adicionar Observação (Sua Demanda)';
            } else if (observationHeader) {
                observationHeader.innerHTML = '<i class="fas fa-comment me-2" style="color: #6f42c1;"></i>Adicionar Observação';
            }
        }

        // Mostrar modal com tratamento de erro
        console.log('🎭 [FRONTEND] Tentando abrir modal...');
        try {
            timelineModal.show();
            console.log('✅ [FRONTEND] Modal aberto com sucesso');
            
            // ✅ AGUARDAR MODAL ESTAR DISPONÍVEL NO DOM ANTES DE ACESSAR ELEMENTOS
            setTimeout(() => {
                console.log('🔍 [FRONTEND] Verificando elementos após abertura do modal...');
                const modalElement = document.getElementById('timelineModal');
                if (modalElement && modalElement.style.display !== 'none') {
                    console.log('✅ [FRONTEND] Modal confirmado como visível');
                    
                    // Reconfirmar acesso aos elementos críticos
                    const demandEditCheck = document.getElementById('demand-edit-section');
                    const interactionCheck = document.getElementById('timeline-interaction-section');
                    const statusCheck = document.getElementById('status-update-section');
                    
                    console.log('🔍 [FRONTEND] Elementos após modal aberto:', {
                        demandEditSection: !!demandEditCheck,
                        interactionSection: !!interactionCheck,
                        statusSection: !!statusCheck
                    });
                    
                    // ✅ CONFIGURAR PERMISSÕES APÓS MODAL ESTAR ABERTO
                    configureModalPermissions(demand, currentUser, currentUserRole);
                } else {
                    console.warn('⚠️ [FRONTEND] Modal não está visível após tentativa de abertura');
                }
            }, 200); // Aumentar timeout para garantir que modal está completamente carregado
            
        } catch (e) {
            console.error('⚠️ [FRONTEND] Erro ao abrir modal bootstrap, usando fallback:', e);
            const el = document.getElementById('timelineModal');
            if (el) { 
                el.style.display = 'block'; 
                el.classList.add('show'); 
                el.removeAttribute('aria-hidden'); 
                console.log('✅ [FRONTEND] Modal aberto via fallback');
            } else {
                console.error('❌ [FRONTEND] Elemento timelineModal não encontrado no DOM');
            }
        }
        
        // Iniciar auto-refresh para manter timeline atualizada
        console.log('🔄 [FRONTEND] Iniciando auto-refresh...');
        startAutoRefresh();
        console.log('🎉 [FRONTEND] viewTimeline concluída com sucesso');
        
        } catch (error) {
            console.error('❌ [FRONTEND] ERRO FATAL ao carregar timeline:', error);
            console.error('❌ [FRONTEND] Stack trace:', error.stack);
            console.error('❌ [FRONTEND] Erro na linha:', error.line || 'desconhecida');
            console.error('❌ [FRONTEND] Tipo do erro:', error.name);
            console.error('❌ [FRONTEND] Mensagem:', error.message);
            showToast('Erro ao carregar timeline da demanda: ' + error.message, 'error');
        }
    };

    // ✅ FUNÇÃO DE DEBUG: Testar visibilidade dos campos
    window.debugTimelineFields = () => {
        console.log('🔍 === DEBUG DOS CAMPOS DA TIMELINE ===');
        
        const demandEditSection = document.getElementById('demand-edit-section');
        const editRealIdField = document.getElementById('edit-real-demand-id');
        const editOpenDateField = document.getElementById('edit-open-date');
        const modal = document.getElementById('timelineModal');
        
        console.log('🔍 Modal da timeline:', {
            existe: !!modal,
            visivel: modal ? window.getComputedStyle(modal).display : 'não existe',
            classe: modal ? modal.className : 'não existe'
        });
        
        console.log('🔍 Seção de edição:', {
            existe: !!demandEditSection,
            display: demandEditSection ? window.getComputedStyle(demandEditSection).display : 'não existe',
            visibility: demandEditSection ? window.getComputedStyle(demandEditSection).visibility : 'não existe',
            height: demandEditSection ? window.getComputedStyle(demandEditSection).height : 'não existe',
            overflow: demandEditSection ? window.getComputedStyle(demandEditSection).overflow : 'não existe'
        });
        
        console.log('🔍 Campo ID Real:', {
            existe: !!editRealIdField,
            visivel: editRealIdField ? window.getComputedStyle(editRealIdField).display : 'não existe',
            valor: editRealIdField ? editRealIdField.value : 'não existe'
        });
        
        console.log('🔍 Campo Data:', {
            existe: !!editOpenDateField,
            visivel: editOpenDateField ? window.getComputedStyle(editOpenDateField).display : 'não existe',
            valor: editOpenDateField ? editOpenDateField.value : 'não existe'
        });
        
        // Forçar visibilidade para teste
        if (demandEditSection) {
            demandEditSection.style.display = 'block !important';
            demandEditSection.style.visibility = 'visible !important';
            demandEditSection.style.opacity = '1 !important';
            demandEditSection.style.height = 'auto !important';
            demandEditSection.style.overflow = 'visible !important';
            console.log('✅ Forçado visibilidade da seção');
        }
    };

    // ✅ FUNÇÃO: Configurar permissões do modal (executada após modal estar aberto)
    async function configureModalPermissions(demand, currentUser, currentUserRole) {
        console.log('🔐 [FRONTEND] Configurando permissões do modal...');
        
        try {
            const users = await getUsers();
            const user = users.find(u => u.username === currentUser) || { 
                username: currentUser, 
                role: currentUserRole
            };
            
            console.log('🔍 [FRONTEND] Buscando elementos DOM das seções...');
            const interactionSection = document.getElementById('timeline-interaction-section');
            const statusUpdateSection = document.getElementById('status-update-section');
            const demandEditSection = document.getElementById('demand-edit-section');
            
            console.log('🔍 [FRONTEND] Elementos encontrados:', {
                interactionSection: !!interactionSection,
                statusUpdateSection: !!statusUpdateSection,
                demandEditSection: !!demandEditSection
            });
            
            const activeNavId = document.querySelector('.nav-link.active')?.id;
            const isGeneralView = activeNavId === 'nav-general-demands';
            const isAdminOrFocalUser = hasFocalPermissions(user.role);
            const isRequester = demand.requester === currentUser;

            console.log('🔐 [FRONTEND] Verificando permissões da timeline:');
            console.log(`  - Usuário atual: ${currentUser}`);
            console.log(`  - Role do usuário: ${user.role}`);
            console.log(`  - Solicitante da demanda: ${demand.requester}`);
            console.log(`  - É admin/focal: ${isAdminOrFocalUser}`);
            console.log(`  - É solicitante: ${isRequester}`);
            console.log(`  - Visão geral: ${isGeneralView}`);

            // Se for visão Demandas Gerais e usuário não é admin/focal: somente visualização
            if (isGeneralView && !isAdminOrFocalUser) {
                console.log('👁️ [FRONTEND] Modo somente visualização');
                if (statusUpdateSection) statusUpdateSection.style.display = 'none';
                if (interactionSection) interactionSection.style.display = 'none';
                if (demandEditSection) demandEditSection.style.display = 'none';
            } else {
            // Status/Prazo: somente Admin ou Focal
            if (isAdminOrFocalUser) {
                console.log('👤 [FRONTEND] Usuário admin/focal - habilitando funcionalidades administrativas');
                if (statusUpdateSection) statusUpdateSection.style.display = 'block';
                
                const deadlineField = document.getElementById('new-deadline-timeline');
                if (deadlineField) {
                    const today = new Date().toISOString().split('T')[0];
                    deadlineField.min = today;
                    if (demand.deadline) {
                        deadlineField.placeholder = formatDeadline(demand.deadline);
                    }
                }
            } else {
                console.log('👤 [FRONTEND] Usuário padrão - funcionalidades básicas');
                if (statusUpdateSection) statusUpdateSection.style.display = 'none';
            }

            // ✅ EDIÇÃO DE CAMPOS BÁSICOS: Disponível para TODOS os usuários
            if (demandEditSection) {
                demandEditSection.style.display = 'block';
                console.log('✅ [FRONTEND] Seção de edição habilitada para todos os usuários');
                
                // ✅ PREENCHER CAMPOS ATUAIS
                const editRealIdField = document.getElementById('edit-real-demand-id');
                const editOpenDateField = document.getElementById('edit-open-date');
                
                if (editRealIdField) {
                    editRealIdField.value = demand.real_demand_id || '';
                    editRealIdField.placeholder = demand.real_demand_id ? demand.real_demand_id : 'Ex: DEM-2024-001';
                    console.log('📝 [FRONTEND] Campo ID Real preenchido:', demand.real_demand_id || 'vazio');
                }
                
                if (editOpenDateField) {
                    if (demand.open_date) {
                        // Converter data para formato YYYY-MM-DD
                        const openDate = new Date(demand.open_date);
                        if (!isNaN(openDate.getTime())) {
                            const dateString = openDate.getFullYear() + '-' + 
                                             String(openDate.getMonth() + 1).padStart(2, '0') + '-' + 
                                             String(openDate.getDate()).padStart(2, '0');
                            editOpenDateField.value = dateString;
                            console.log('📅 [FRONTEND] Campo Data Abertura preenchido:', dateString);
                        } else {
                            console.log('📅 [FRONTEND] Data de abertura inválida, deixando campo vazio');
                        }
                    } else {
                        console.log('📅 [FRONTEND] Campo Data Abertura vazio (usuário pode preencher)');
                    }
                }
                
            } else {
                console.warn('⚠️ [FRONTEND] Elemento demand-edit-section não encontrado no DOM');
            }

                // Observações podem ser adicionadas por admin/focal ou solicitante
                const canAddObservation = isAdminOrFocalUser || isRequester;
                if (interactionSection) {
                    interactionSection.style.display = canAddObservation ? 'block' : 'none';
                    console.log(`📝 [FRONTEND] Seção de observações: ${canAddObservation ? 'habilitada' : 'desabilitada'}`);
                }
                
                // Atualizar o texto do card para deixar claro a regra
                const observationHeader = document.querySelector('#timeline-interaction-section .card-header h6');
                if (observationHeader && isRequester && !isAdminOrFocalUser) {
                    observationHeader.innerHTML = '<i class="fas fa-comment me-2" style="color: #6f42c1;"></i>Adicionar Observação (Sua Demanda)';
                } else if (observationHeader) {
                    observationHeader.innerHTML = '<i class="fas fa-comment me-2" style="color: #6f42c1;"></i>Adicionar Observação';
                }
            }
            
            console.log('✅ [FRONTEND] Permissões configuradas com sucesso');
            
        } catch (error) {
            console.error('❌ [FRONTEND] Erro ao configurar permissões:', error);
        }
    }

    // Mostrar modal de classificação
    window.showClassificationModal = () => {
        // Limpar formulário
        document.getElementById('classificationForm').reset();
        document.getElementById('calculated-score').textContent = '0';
        document.getElementById('priority-level').textContent = 'Baixa';
        
        // Event listeners para cálculo em tempo real
        document.querySelectorAll('.classification-select').forEach(select => {
            select.addEventListener('change', calculateClassificationScore);
        });
        
        classificationModal.show();
    };

    // Calcular pontuação de classificação
    window.calculateClassificationScore = () => {
        let score = 0;
        const form = document.getElementById('classificationForm');
        const formData = new FormData(form);
        
        // Perguntas 1-7 (1-3 pontos cada)
        for (let i = 1; i <= 7; i++) {
            const value = formData.get(Object.keys(formData)[i-1]);
            if (value) score += parseInt(value);
        }
        
        // Perguntas 8-9 (Sim = 1, Não = 0)
        const gestao = formData.get('gestao_equipes_direta');
        const envolvimento = formData.get('envolvimento_grupos');
        if (gestao === 'sim') score += 1;
        if (envolvimento === 'sim') score += 1;
        
        // Pergunta 10 (Sim = 0, Não = 1)
        const gerarCasa = formData.get('gerar_dentro_casa');
        if (gerarCasa === 'nao') score += 1;
        
        // Atualizar display
        document.getElementById('calculated-score').textContent = score;
        
        // Determinar nível de prioridade
        let priorityLevel = 'Baixa';
        let priorityClass = 'bg-success';
        
        if (score >= 18) {
            priorityLevel = 'Alta';
            priorityClass = 'bg-danger';
        } else if (score >= 12) {
            priorityLevel = 'Média';
            priorityClass = 'bg-warning';
        }
        
        const priorityElement = document.getElementById('priority-level');
        priorityElement.textContent = priorityLevel;
        priorityElement.className = `badge ${priorityClass}`;
    };

    // Submeter classificação
    window.submitClassification = () => {
        const form = document.getElementById('classificationForm');
        if (!form.checkValidity()) {
            form.reportValidity();
            return;
        }
        
        const score = parseInt(document.getElementById('calculated-score').textContent);
        const priority = document.getElementById('priority-level').textContent;
        
        // Aqui você pode salvar a classificação
        showToast(`Classificação salva: ${score} pontos (${priority})`, 'success');
        classificationModal.hide();
    };

    // Adicionar observação na timeline
    window.addTimelineInteraction = async () => {
        const observation = document.getElementById('timeline-observation').value.trim();
        if (!observation) {
            showToast('Digite uma observação', 'error');
            return;
        }
        
        if (!currentDemandId) {
            showToast('Erro: ID da demanda não encontrado', 'error');
            return;
        }
        
        try {
            console.log('📝 Adicionando observação na timeline...');
            console.log('📝 Demanda ID:', currentDemandId);
            console.log('📝 Observação:', observation);
            
            // ✅ USAR API PRINCIPAL - Endpoint que funciona corretamente
            const response = await fetch(`/api/demands/${currentDemandId}/timeline`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify({ 
                    event_text: observation,
                    user_id: currentUser // Enviar o usuário atual
                })
            });
            
            console.log('📨 Response status:', response.status);
            console.log('📨 Response ok:', response.ok);
            
            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Response error:', errorText);
                throw new Error(`HTTP ${response.status}: ${errorText}`);
            }
            
            const result = await response.json();
            console.log('✅ Response data:', result);
            
            if (result && result.success) {
                console.log('✅ Entrada adicionada na timeline com ID:', result.data?.id);
                
                // Limpar campo imediatamente
                document.getElementById('timeline-observation').value = '';
                
                // ✅ FEEDBACK INSTANTÂNEO - Mostrar toast primeiro
                showToast('Observação adicionada com sucesso', 'success');
                
                // ✅ REFRESH IMEDIATO - Atualizar timeline sem delay
                setTimeout(async () => {
                    await refreshTimelineView(currentDemandId);
                    console.log('🔄 Timeline atualizada automaticamente');
                }, 200); // Delay mínimo para garantir que o banco foi atualizado
                
            } else {
                throw new Error(result?.error || 'Erro desconhecido na resposta');
            }
            
        } catch (error) {
            console.error('❌ Erro ao adicionar observação:', error);
            showToast(`Erro ao adicionar observação: ${error.message}`, 'error');
        }
    };

    // ✅ NOVA FUNÇÃO: Atualizar informações da demanda (ID Real e Data Abertura)
    window.updateDemandInfo = async () => {
        const newRealId = document.getElementById('edit-real-demand-id').value.trim();
        const newOpenDate = document.getElementById('edit-open-date').value;
        
        if (!newRealId && !newOpenDate) {
            showToast('Preencha pelo menos um campo para atualizar', 'error');
            return;
        }
        
        if (!currentDemandId) {
            showToast('Erro: ID da demanda não encontrado', 'error');
            return;
        }
        
        try {
            console.log('📝 [FRONTEND] Atualizando informações da demanda via timeline...');
            console.log('📝 [FRONTEND] Demanda ID:', currentDemandId);
            console.log('📝 [FRONTEND] Novo ID Real:', newRealId || 'não alterado');
            console.log('📝 [FRONTEND] Nova data abertura:', newOpenDate || 'não alterado');
            
            // Preparar dados para atualização usando o novo endpoint
            const updateData = {
                user_id: currentUser || 'anonimo',
                user_name: currentUser || 'Usuário Anônimo'
            };
            
            // Adicionar campos apenas se preenchidos
            if (newRealId) {
                updateData.real_demand_id = newRealId;
            }
            
            if (newOpenDate) {
                updateData.open_date = newOpenDate;
            }
            
            console.log('📤 [FRONTEND] Dados de atualização:', updateData);
            
            // Usar o novo endpoint específico para edição via timeline
            const response = await fetch(`/api/demands/${currentDemandId}/timeline-edit`, {
                method: 'PATCH',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(updateData)
            });
            
            console.log('📨 [FRONTEND] Response status:', response.status);
            
            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ [FRONTEND] Response error:', errorText);
                throw new Error(`HTTP ${response.status}: ${errorText}`);
            }
            
            const result = await response.json();
            console.log('✅ [FRONTEND] Informações atualizadas:', result);
            
            // ✅ FEEDBACK E REFRESH
            showToast('Informações atualizadas com sucesso! Timeline registrada.', 'success');
            
            // Refresh imediato da timeline e detalhes
            setTimeout(async () => {
                console.log('🔄 [FRONTEND] Atualizando timeline...');
                await refreshTimelineView(currentDemandId);
                
                // Recarregar demandas e reabrir o modal atualizado
                await loadDemandsFromApi();
                const updatedDemand = getDemands().find(d => d.id === currentDemandId);
                if (updatedDemand) {
                    console.log('🔄 [FRONTEND] Reabrindo modal com dados atualizados...');
                    await window.viewTimeline(currentDemandId);
                }
            }, 500);
            
            // Refresh das listas
            setTimeout(async () => {
                await loadDemandsFromApi();
                await refreshCurrentView();
            }, 800);
            
        } catch (error) {
            console.error('❌ [FRONTEND] Erro ao atualizar informações:', error);
            showToast(`Erro ao atualizar informações: ${error.message}`, 'error');
        }
    };

    // Atualizar status da demanda
    window.updateDemandStatus = async () => {
        const newStatus = document.getElementById('new-status').value;
        const newDeadline = document.getElementById('new-deadline-timeline').value;
        
        if (!newStatus && !newDeadline) {
            showToast('Selecione um status ou defina um prazo', 'error');
            return;
        }
        
        if (!currentDemandId) {
            showToast('Erro: ID da demanda não encontrado', 'error');
            return;
        }
        
        try {
            console.log('📝 Atualizando demanda...');
            console.log('📝 Demanda ID:', currentDemandId);
            console.log('📝 Novo status:', newStatus);
            console.log('📝 Novo prazo:', newDeadline);
            
            // Preparar dados para atualização
            const updateData = {};
            let timelineMessage = '';
            
            // Adicionar status se fornecido
            if (newStatus) {
                updateData.status = newStatus;
                timelineMessage += `Status alterado para "${newStatus}"`;
            }
            
            // Adicionar prazo se fornecido
            if (newDeadline) {
                updateData.deadline = newDeadline;
                if (timelineMessage) {
                    timelineMessage += ` e prazo definido para ${new Date(newDeadline).toLocaleDateString()}`;
                } else {
                    timelineMessage = `Prazo definido para ${new Date(newDeadline).toLocaleDateString()}`;
                }
            }
            
            console.log('📤 Dados de atualização:', updateData);
            
            // Atualizar demanda via API
            const response = await fetch(`/api/demands/${currentDemandId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(updateData)
            });
            
            console.log('📨 Response status:', response.status);
            
            if (!response.ok) {
                const errorText = await response.text();
                console.error('❌ Response error:', errorText);
                throw new Error(`HTTP ${response.status}: ${errorText}`);
            }
            
            const result = await response.json();
            console.log('✅ Demanda atualizada:', result);
            
            // Adicionar entrada na timeline se houve mudança
            if (timelineMessage) {
                console.log('📝 Adicionando entrada na timeline...');
                
                const timelineResponse = await fetch(`/api/demands/${currentDemandId}/timeline`, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify({ 
                        event_text: timelineMessage,
                        user_id: currentUser // Enviar o usuário atual
                    })
                });
                
                if (timelineResponse.ok) {
                    const timelineResult = await timelineResponse.json();
                    console.log('✅ Timeline atualizada:', timelineResult);
                }
            }
            
            // Limpar campos
            document.getElementById('new-status').value = '';
            document.getElementById('new-deadline-timeline').value = '';
            
            // ✅ FEEDBACK INSTANTÂNEO E REFRESH RÁPIDO
            showToast(`Demanda atualizada com sucesso`, 'success');
            
            // ✅ REFRESH IMEDIATO DA TIMELINE
            setTimeout(async () => {
                await refreshTimelineView(currentDemandId);
                console.log('🔄 Timeline atualizada após mudança de status');
            }, 300); // Delay mínimo para garantir processamento
            
            // 🆕 REFRESH RÁPIDO DAS LISTAS (melhorado)
            setTimeout(async () => {
                console.log('🔄 Forçando refresh das listas após atualização...');
                await loadDemandsFromApi(); // Recarregar do servidor
                await refreshCurrentView(); // Atualizar a tela atual
                console.log('✅ Listas atualizadas após mudança de status!');
            }, 500); // Delay reduzido de 1000ms para 500ms
            
        } catch (error) {
            console.error('❌ Erro ao atualizar demanda:', error);
            showToast(`Erro ao atualizar demanda: ${error.message}`, 'error');
        }
    };

    // Mostrar modal de redistribuição
    window.showRedistributeModal = async (demandId) => {
        currentDemandId = demandId;
        
        try {
            // Garantir que usuários estão carregados
            if (!usersCache || usersCache.length === 0) {
                await loadUsersFromApi();
            }
            
            // Buscar TODOS os usuários do banco (já que todo admin é focal)
            let availableUsers = [];
            
            // Primeira opção: usar todos os usuários do cache da API
            if (usersCache && usersCache.length > 0) {
                availableUsers = usersCache.map(user => ({
                    username: user.id,
                    name: user.name || user.id
                }));
                console.log('✅ Usando todos os usuários do banco para redistribuição:', availableUsers.length);
            } else {
                // Fallback: tentar buscar focais e admins do roles
                try {
                    const rolesResponse = await fetch('/api/roles');
                    if (rolesResponse.ok) {
                        const rolesData = await rolesResponse.json();
                        if (rolesData.success) {
                            // Combinar admins e focais (eliminar duplicatas)
                            const allRoles = [...(rolesData.data.admins || []), ...(rolesData.data.focals || [])];
                            const uniqueRoles = [...new Set(allRoles)];
                            
                            availableUsers = uniqueRoles.map(userId => {
                                const userName = getUserName(userId) || userId;
                                return { username: userId, name: userName };
                            });
                        }
                    }
                } catch (e) {
                    console.log('⚠️ Falha ao buscar roles do backend');
                }
                
                // Fallback final: lista hardcoded
                if (availableUsers.length === 0) {
                    availableUsers = [
                        { username: 'g0040925', name: getUserName('g0040925') || 'G0040925' },
                        { username: 'g005523', name: getUserName('g005523') || 'G005523' },
                        { username: 'a0094512', name: getUserName('a0094512') || 'A0094512' },
                        { username: 'a0074849', name: getUserName('a0074849') || 'A0074849' },
                        { username: 'a0125079', name: getUserName('a0125079') || 'A0125079' },
                        { username: 'a0075020', name: getUserName('a0075020') || 'A0075020' },
                        { username: 'g0040902', name: getUserName('g0040902') || 'G0040902' },
                        { username: 'a0162350', name: getUserName('a0162350') || 'A0162350' }
                    ];
                }
            }
            
            // Ordenar alfabeticamente por nome
            availableUsers.sort((a, b) => a.name.localeCompare(b.name, 'pt-BR', { sensitivity: 'base' }));
            
            const select = document.getElementById('new-responsible');
            select.innerHTML = '<option value="">Selecione um responsável...</option>';
            
            availableUsers.forEach(user => {
                const option = document.createElement('option');
                option.value = user.username;
                option.textContent = user.name;
                select.appendChild(option);
            });
            
            console.log(`📋 ${availableUsers.length} usuários disponíveis para redistribuição`);
        
        try {
            if (redistributeModal && redistributeModal.show) {
                redistributeModal.show();
            } else {
                const el = document.getElementById('redistributeModal');
                showModalFallback(el);
            }
        } catch (_) {
            const el = document.getElementById('redistributeModal');
            showModalFallback(el);
        }
        } catch (error) {
            console.error('❌ Erro ao abrir modal de redistribuição:', error);
            showToast('Erro ao carregar focais disponíveis', 'error');
        }
    };

    // Confirmar redistribuição
    window.confirmRedistribute = async () => {
        try {
            const newResponsible = document.getElementById('new-responsible').value;
            const observation = document.getElementById('redistribute-observation').value.trim();
            
            if (!newResponsible) {
                showToast('Selecione um focal responsável', 'error');
                return;
            }

            // Atualizar no backend via API
            try {
                const updateResponse = await apiRequest(`/demands/${currentDemandId}`, {
                    method: 'PUT',
                    body: JSON.stringify({
                        responsible: newResponsible,
                        observation: observation || 'Redistribuição realizada pelo administrador'
                    })
                });

                if (updateResponse && updateResponse.success) {
                    console.log('✅ Demanda redistribuída com sucesso no backend');
                    
                    // Atualizar cache local
                    const demands = await getDemands();
                    const demand = demands.find(d => d.id === currentDemandId);
                    if (demand) {
                        demand.responsible = newResponsible;
                        
                        // Adicionar evento à timeline
                        if (!demand.timeline) demand.timeline = [];
                        
                        const newEvent = {
                            id: demand.timeline.length + 1,
                            type: 'redistribution',
                            user: currentUser,
                            timestamp: new Date().toISOString(),
                            message: `Demanda redistribuída para ${getUserName(newResponsible)}`,
                            details: observation || 'Redistribuição realizada pelo administrador'
                        };
                        
                        demand.timeline.push(newEvent);
                    }
                    
                    // Recarregar dados para atualizar a tela
                    console.log('🔄 Forçando refresh após redistribuição...');
                    await loadDemandsFromApi();
                    await refreshCurrentView();
                    console.log('✅ Listas atualizadas após redistribuição!');
                    
                    showToast('Demanda redistribuída com sucesso!', 'success');
                } else {
                    throw new Error('Falha na resposta da API');
                }
            } catch (apiError) {
                console.error('❌ Erro ao redistribuir via API:', apiError);
                showToast('Erro ao redistribuir demanda', 'error');
                return;
            }
        
            // Limpar campos
            document.getElementById('new-responsible').value = '';
            document.getElementById('redistribute-observation').value = '';
            
            try {
                if (redistributeModal && redistributeModal.hide) {
                    redistributeModal.hide();
                } else {
                    const el = document.getElementById('redistributeModal');
                    hideModalAny(el);
            }
        } catch (_) {
            const el = document.getElementById('redistributeModal');
            hideModalAny(el);
        }
        showToast(`Demanda redistribuída para ${getUserName(newResponsible)}`, 'success');
        
        // Atualizar painel admin
        renderAdminPanel();
        } catch (error) {
            console.error('❌ Erro ao redistribuir demanda:', error);
            showToast('Erro ao redistribuir demanda', 'error');
        }
    };

    // Mostrar seção (global)
    window.showSection = showSection;

    // ===== INICIALIZAÇÃO =====

    // Inicializar aplicação
    updateUserInfo();
    // Abre homepage ao iniciar com dados carregados
    showSection('home');
    (async () => {
        await renderHome();
    })();
    
    // Remover loader inicial imediatamente
    const loader = document.getElementById('initial-loader');
    if (loader) {
        loader.style.display = 'none';
    }

    // ✅ FUNÇÃO DE TESTE - Verificar se o problema está no frontend ou backend
    window.testTimelineAPI = async () => {
        console.log('🧪 TESTE: Verificando API de timeline...');
        
        try {
            // Teste 1: Verificar se a API responde
            console.log('🧪 Teste 1: Verificando resposta da API...');
            const response = await fetch('/api/demands/19/timeline', {
                method: 'GET',
                headers: { 'Accept': 'application/json' }
            });
            
            console.log('🧪 GET /api/demands/19/timeline - Status:', response.status);
            
            if (response.ok) {
                const data = await response.json();
                console.log('🧪 GET Response:', data);
            }
            
            // Teste 2: Verificar se o POST funciona na API alternativa
            console.log('🧪 Teste 2: Verificando POST da API alternativa /api/timeline...');
            const testData = { 
                demand_id: 19,
                event_text: 'TESTE - ' + new Date().toISOString() 
            };
            console.log('🧪 Dados de teste:', testData);
            console.log('🧪 JSON stringificado:', JSON.stringify(testData));
            
            const postResponse = await fetch('/api/timeline', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(testData)
            });
            
            console.log('🧪 POST /api/timeline - Status:', postResponse.status);
            console.log('🧪 POST Headers:', postResponse.headers);
            
            if (postResponse.ok) {
                const postData = await postResponse.json();
                console.log('🧪 POST Response:', postData);
            } else {
                const errorText = await postResponse.text();
                console.log('🧪 POST Error:', errorText);
            }
            
        } catch (error) {
            console.error('🧪 Erro no teste:', error);
        }
    };

    // ✅ DIAGNÓSTICO COMPLETO - Descobrir APIs disponíveis
    window.diagnosticoCompleto = async () => {
        console.log('🔍 DIAGNÓSTICO COMPLETO: Descobrindo APIs disponíveis...');
        
        // Testar todas as APIs possíveis
        const apis = [
            '/api/demands',
            '/api/users',
            '/api/current-user',
            '/api/timeline',
            '/api/demands/19/timeline',
            '/api/demands/timeline',
            '/timeline',
            '/demands/19/timeline'
        ];
        
        console.log('🔍 Testando APIs...');
        
        for (const api of apis) {
            try {
                console.log(`🔍 Testando ${api}...`);
                const response = await fetch(api, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                });
                console.log(`🔍 ${api} - Status: ${response.status} ${response.statusText}`);
                
                if (response.ok) {
                    try {
                        const data = await response.json();
                        console.log(`🔍 ${api} - Response:`, data);
                    } catch (e) {
                        console.log(`🔍 ${api} - Response não é JSON válido`);
                    }
                }
            } catch (error) {
                console.log(`🔍 ${api} - Erro:`, error.message);
            }
        }
        
        // Testar métodos POST
        console.log('🔍 Testando métodos POST...');
        
        const postApis = [
            '/api/timeline',
            '/api/demands/19/timeline',
            '/timeline',
            '/demands/19/timeline'
        ];
        
        for (const api of postApis) {
            try {
                console.log(`🔍 Testando POST ${api}...`);
                const testData = { 
                    demand_id: 19,
                    event_text: 'TESTE DIAGNÓSTICO' 
                };
                
                const response = await fetch(api, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(testData)
                });
                
                console.log(`🔍 POST ${api} - Status: ${response.status} ${response.statusText}`);
                
                if (response.ok) {
                    try {
                        const data = await response.json();
                        console.log(`🔍 POST ${api} - Response:`, data);
                    } catch (e) {
                        console.log(`🔍 POST ${api} - Response não é JSON válido`);
                    }
                } else {
                    const errorText = await response.text();
                    console.log(`🔍 POST ${api} - Error:`, errorText);
                }
            } catch (error) {
                console.log(`🔍 POST ${api} - Erro:`, error.message);
            }
        }
        
        console.log('🔍 DIAGNÓSTICO COMPLETO FINALIZADO!');
    };

    // ✅ FUNÇÃO DE TESTE RÁPIDO - Verificar APIs disponíveis
    window.testAvailableAPIs = async () => {
        console.log('🧪 TESTE RÁPIDO: Verificando APIs disponíveis...');
        
        const apis = [
            '/api/demands',
            '/api/timeline',
            '/api/users',
            '/api/current-user'
        ];
        
        for (const api of apis) {
            try {
                console.log(`🧪 Testando ${api}...`);
                const response = await fetch(api, {
                    method: 'GET',
                    headers: { 'Accept': 'application/json' }
                });
                console.log(`🧪 ${api} - Status: ${response.status} ${response.statusText}`);
                
                if (response.ok) {
                    const data = await response.json();
                    console.log(`🧪 ${api} - Response:`, data);
                }
            } catch (error) {
                console.log(`🧪 ${api} - Erro:`, error.message);
            }
        }
    };

    // ✅ FUNÇÃO DE TESTE - Verificar se o problema está no frontend ou backend
    
    // ===============================
    // 🚀 INICIALIZAÇÃO DA APLICAÇÃO
    // ===============================
    
    try {
        console.log('🚀 Iniciando aplicação...');
        
        // Inicializar a aplicação
        await initializeApp();
        
        console.log('✅ Aplicação inicializada com sucesso!');
        
        // Renderizar a home por padrão
        await renderHome();
        
        console.log('✅ Home renderizada com sucesso!');
        
    } catch (error) {
        console.error('🚨 ERRO CRÍTICO na inicialização:', error);
        
        // Mostrar erro na tela
        if (appContent) {
            appContent.innerHTML = `
                <div class="alert alert-danger">
                    <h4>🚨 Erro na Inicialização</h4>
                    <p><strong>Não foi possível carregar o sistema.</strong></p>
                    <p><strong>Erro:</strong> ${error.message}</p>
                    <pre style="background: #f8f9fa; padding: 10px; border-radius: 4px; font-size: 12px; overflow-x: auto;">${error.stack}</pre>
                    <button class="btn btn-primary" onclick="location.reload()">🔄 Tentar Novamente</button>
                </div>
            `;
        }
    }
});

// ✅ FUNÇÃO SIMPLES: Atualizar um campo específico da demanda
async function updateDemandField(demandId, fieldName, newValue) {
    try {
        console.log(`🔧 Atualizando demanda ${demandId}: ${fieldName} = "${newValue}"`);
        
        const payload = {};
        payload[fieldName] = newValue;
        
        const response = await fetch(`/api/demands/${demandId}/update-field`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        
        const result = await response.json();
        
        if (result.success) {
            window.showToast(`Campo "${fieldName}" atualizado com sucesso!`, 'success');
            
            // Recarregar as tabelas para mostrar a mudança
            const activeSection = document.querySelector('.nav-link.active')?.id;
            if (activeSection === 'nav-my-requests') {
                await window.renderMyRequests();
            } else if (activeSection === 'nav-general-demands') {
                await window.renderGeneralDemands();
            }
        } else {
            throw new Error(result.error || 'Erro desconhecido');
        }
        
    } catch (error) {
        console.error('❌ Erro ao atualizar campo:', error);
        window.showToast(`Erro ao atualizar: ${error.message}`, 'error');
    }
}

// ✅ FUNÇÃO: Modal bonito para editar campos
function showEditModal(title, label, currentValue, inputType, onSave) {
    // Criar modal dinamicamente
    const modalId = 'editFieldModal';
    const existingModal = document.getElementById(modalId);
    if (existingModal) {
        existingModal.remove();
    }
    
    const modal = document.createElement('div');
    modal.className = 'modal fade';
    modal.id = modalId;
    modal.innerHTML = `
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">${title}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">${label}</label>
                        <input type="${inputType}" class="form-control" id="editFieldInput" value="${currentValue}">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="saveFieldBtn">Salvar</button>
                </div>
            </div>
        </div>
    `;
    
    document.body.appendChild(modal);
    
    // Event listeners
    const input = modal.querySelector('#editFieldInput');
    const saveBtn = modal.querySelector('#saveFieldBtn');
    
    saveBtn.addEventListener('click', () => {
        const newValue = input.value.trim();
        onSave(newValue);
        
        // Fechar modal
        if (window.bootstrap && bootstrap.Modal) {
            const bsModal = bootstrap.Modal.getInstance(modal) || new bootstrap.Modal(modal);
            bsModal.hide();
        } else {
            modal.style.display = 'none';
            modal.classList.remove('show');
        }
    });
    
    // Enter para salvar
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            saveBtn.click();
        }
    });
    
    // Mostrar modal
    if (window.bootstrap && bootstrap.Modal) {
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    } else {
        modal.style.display = 'block';
        modal.classList.add('show');
    }
    
    // Focar no input
    setTimeout(() => {
        input.focus();
        input.select();
    }, 100);
    
    // Remover modal do DOM quando fechar
    modal.addEventListener('hidden.bs.modal', () => {
        modal.remove();
    });
}